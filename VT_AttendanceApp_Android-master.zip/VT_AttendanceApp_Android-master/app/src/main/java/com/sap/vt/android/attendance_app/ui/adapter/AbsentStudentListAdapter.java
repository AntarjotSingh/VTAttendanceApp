package com.sap.vt.android.attendance_app.ui.adapter;

import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.sap.vt.android.attendance_app.model.Student;

import java.util.List;

/**
 * Created by I327891 on 12-Jul-17.
 */

public class AbsentStudentListAdapter extends StudentListAdapter {
    public AbsentStudentListAdapter(List<Student> studentList) {
        super(studentList);
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        super.onBindViewHolder(holder, position);
        ((StudentItemViewHolder) holder).absentCheckbox.setVisibility(View.GONE);
    }
}
