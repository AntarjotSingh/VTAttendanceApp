package com.sap.vt.android.attendance_app.ui.fragment;

/**
 * Created by I327891 on 11-Jul-17.
 */

public interface FragmentListener {
    void onFragmentUpdate(String currentFragment, Object parameter);
}
