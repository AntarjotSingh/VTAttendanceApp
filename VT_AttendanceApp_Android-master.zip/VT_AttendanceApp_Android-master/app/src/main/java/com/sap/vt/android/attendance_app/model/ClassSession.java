package com.sap.vt.android.attendance_app.model;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by I327891 on 11-Jul-17.
 */

public class ClassSession {
    private final int index;
    private final String ID;
    private final Subject subject;
    private final int semester;
    private Status status;
    private int sessionNumber;
    private int maxSessionNumber;
    private boolean isModifiable;
    private Batch batch;
    private List<Student> absentStudentList;

    public ClassSession(int index, String ID, Subject subject, int sessionNumber, int semester, Status status, boolean isModifiable) {
        this.index = index;
        this.ID = ID;
        this.subject = subject;
        this.isModifiable = isModifiable;
        this.status = status;

        this.sessionNumber = sessionNumber;
        this.semester = semester;

        this.absentStudentList = new ArrayList<>();
        this.maxSessionNumber = 1;
    }

    public int getIndex() {
        return index;
    }

    public String getID() {
        return ID;
    }

    public Batch getBatch() {
        return batch;
    }

    public void setBatch(Batch batch) {
        this.batch = batch;
        this.refreshAbsenteeList();
    }

    public int getSessionNumber() {
        return sessionNumber;
    }

    public void setSessionNumber(int sessionNumber) {
        this.sessionNumber = sessionNumber;
    }

    public int getMaxSessionNumber() {
        return maxSessionNumber;
    }

    public void setMaxSessionNumber(int maxSessionNumber) {
        this.maxSessionNumber = maxSessionNumber;
    }

    public int getSemester() {
        return semester;
    }

    public Subject getSubject() {
        return subject;
    }

    public boolean isNew() {
        return this.status.equals(Status.UNMARKED);
    }

    public boolean isModifiable() {
        return isModifiable;
    }

    public void setModifiable(boolean modifiable) {
        isModifiable = modifiable;
    }

    public boolean isApproved() {
        return this.status.equals(Status.APPROVED);
    }

    public boolean hasDiscrepancy() {
        return this.status.equals(Status.DISCREPANCY);
    }

    public Status getStatus() {
        return this.status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

    public void updateStudentList(List<Student> studentList) {
        this.batch.setStudentList(studentList);
        this.refreshAbsenteeList();
    }

    public void refreshAbsenteeList() {
        this.absentStudentList.clear();
        for (Student student : this.batch.getStudentList()) {
            if (student.isAbsent()) {
                this.absentStudentList.add(student);
            }
        }
    }

    public List<Student> getAbsentStudentList() {
        return absentStudentList;
    }

    public enum Status {
        UNMARKED,                   //New
        WAITING_FOR_APPROVAL,       //marked by faculty, but waiting for approval by VT
        DISCREPANCY,                //marked by faculty, but has discrepancy
        APPROVED                    //marked by faculty, and approved by VT
    }
}
