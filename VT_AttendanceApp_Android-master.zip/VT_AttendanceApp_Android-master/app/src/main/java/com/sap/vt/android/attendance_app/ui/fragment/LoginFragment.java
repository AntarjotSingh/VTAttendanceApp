package com.sap.vt.android.attendance_app.ui.fragment;

import android.app.Activity;
import android.app.Fragment;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.support.design.widget.TextInputEditText;
import android.support.design.widget.TextInputLayout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.sap.vt.R;
import com.sap.vt.android.attendance_app.service.Persistence;
import com.sap.vt.android.attendance_app.ui.Banner;
import com.sap.vt.android.attendance_app.ui.activity.LoginActivity;

/**
 * Created by I327891 on 25-Jul-17.
 */

public class LoginFragment extends Fragment implements View.OnClickListener {

    public final static String TAG = "Fragment.Login";

    Button loginButton;
    TextInputLayout emailTextInputLayout, passwordTextInputLayout;
    TextInputEditText emailEditText, passwordEditText;
    TextView contactSupportTextView;
    FragmentListener mListener;

    String[] credentials = new String[2];

    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_login, container, false);
        emailEditText = (TextInputEditText) view.findViewById(R.id.login_email);
        contactSupportTextView = (TextView) view.findViewById(R.id.contactSupport);
        emailTextInputLayout = (TextInputLayout) view.findViewById(R.id.login_layout_email);
        passwordEditText = (TextInputEditText) view.findViewById(R.id.login_password);
        passwordTextInputLayout = (TextInputLayout) view.findViewById(R.id.login_layout_password);
        loginButton = (Button) view.findViewById(R.id.login_button);
        loginButton.setOnClickListener(this);
        contactSupportTextView.setOnClickListener(this);
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                emailTextInputLayout.setVisibility(View.VISIBLE);
                passwordTextInputLayout.setVisibility(View.VISIBLE);
            }
        }, LoginActivity.FADE_DEFAULT_TIME + LoginActivity.MOVE_DEFAULT_TIME);
        return view;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof LoginActivity) {
            this.mListener = (FragmentListener) getActivity();
        }
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        if (activity instanceof LoginActivity) {
            this.mListener = (FragmentListener) getActivity();
        }
    }

//    private boolean isEmailValid() {
////        boolean isValid = emailEditText.getText().toString().contains("@");
////        return isValid;
////    }

    private boolean isValidMail() {
        return android.util.Patterns.EMAIL_ADDRESS.matcher(emailEditText.getText().toString()).matches();
    }

    private boolean isPasswordValid() {
        boolean isValid = passwordEditText.getText().toString().length() > 0;
        return isValid;
    }

    public void setError(boolean isValid) {
        emailTextInputLayout.setError(!isValid ? null : getResources().getString(R.string.error_invalid_email));
        passwordTextInputLayout.setError(!isValid ? null : getResources().getString(R.string.error_incorrect_password));
    }

    private boolean isValidMobile() {
        return android.util.Patterns.PHONE.matcher(emailEditText.getText().toString()).matches();
    }

    @Override
    public void onClick(View v) {
        if (v == loginButton) {
            if ((isValidMail() || isValidMobile()) && isPasswordValid()) {
                credentials[0] = emailEditText.getText().toString();
                credentials[1] = passwordEditText.getText().toString();
                this.mListener.onFragmentUpdate(TAG, credentials);
            } else {
                this.mListener.onFragmentUpdate(TAG, null);
            }
        } else if(v == contactSupportTextView){
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType("message/rfc822");
            i.putExtra(Intent.EXTRA_EMAIL  , new String[]{Persistence.getInstance(getActivity().getApplicationContext()).getPrefSupportEmail()});
            i.putExtra(Intent.EXTRA_SUBJECT,  getResources().getString(R.string.support_email_subject));
            i.putExtra(Intent.EXTRA_TEXT   ,  getResources().getString(R.string.support_email_body));
            try {
                startActivity(Intent.createChooser(i,  getResources().getString(R.string.send_email)));
            } catch (android.content.ActivityNotFoundException ex) {
                Banner.showErrorBanner(getResources().getString(R.string.email_client_not_found));
            }
        }
    }
}
