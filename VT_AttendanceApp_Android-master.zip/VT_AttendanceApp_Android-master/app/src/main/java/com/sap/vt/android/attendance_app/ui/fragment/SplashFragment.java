package com.sap.vt.android.attendance_app.ui.fragment;

import android.app.Fragment;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.sap.vt.R;

import de.hdodenhof.circleimageview.CircleImageView;
import me.zhanghai.android.materialprogressbar.MaterialProgressBar;

/**
 * Created by I327891 on 25-Jul-17.
 */

public class SplashFragment extends Fragment {

    public final static String TAG = "Fragment.Splash";

    private CircleImageView circleImageView;
    private MaterialProgressBar progressBar;

    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_splash, container, false);
        circleImageView = (CircleImageView) view.findViewById(R.id.splash_icon);
        progressBar = (MaterialProgressBar) view.findViewById(R.id.splash_progress);
        return view;
    }

    public View getCircleImageView() {
        return this.circleImageView;
    }

    public void setIndeterminateProgressBarVisible(boolean visible) {
        if (visible) {
            progressBar.setVisibility(View.VISIBLE);
        } else {
            progressBar.setVisibility(View.GONE);
        }
    }

}
