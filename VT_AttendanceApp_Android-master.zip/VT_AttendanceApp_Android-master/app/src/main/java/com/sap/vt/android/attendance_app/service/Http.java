package com.sap.vt.android.attendance_app.service;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.util.Base64;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.sap.vt.android.attendance_app.ui.activity.BaseActivity;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by I327891 on 23-Jul-17.
 */


public class Http extends BaseActivity {

    public final static String DataBase_BaseUrl= "https://vtprojectsabab1db02.hana.ondemand.com/Database_Details_AA/Service/";
    public final static String DataBase_EndPoint= "getDatabaseDetails.xsjs";
    public final static String ERR_NETWORK_UNAVAILABLE = "Network unavailable";

    private static Http mInstance;

    private Context mContext;
    private RequestQueue mRequestQueue;

    private Http(Context context) {
        this.mContext = context;
        this.mRequestQueue = Volley.newRequestQueue(mContext.getApplicationContext());
    }

    public static Http getInstance(Context context) {
        if (mInstance == null) {
            mInstance = new Http(context);
        }
        return mInstance;
    }

    public boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager = (ConnectivityManager) mContext.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }

    private RequestQueue getRequestQueue() {
        return this.mRequestQueue;
    }

    private void makeRequest(Request request) {
        this.getRequestQueue().add(request);
    }

    public void makeStringRequest(int method, String url, Response.Listener listener, Response.ErrorListener errorListener) {
        if (isNetworkAvailable()) {
            StringRequest request = new StringRequest(method, url, listener, errorListener) {
                @Override
                public Map<String, String> getHeaders() throws AuthFailureError {
                    Map<String, String> params = new HashMap<String, String>();
                    String credentials = "Aditya:System123456789";
                    String auth = "Basic " + Base64.encodeToString(credentials.getBytes(), Base64.NO_WRAP);
                    params.put("Authorization", auth);
                    return params;
                }
            };
            this.makeRequest(request);
        } else {
            errorListener.onErrorResponse(new VolleyError(ERR_NETWORK_UNAVAILABLE));
        }
    }

    public void makeStringRequestBasicAuth(int method, String url, Response.Listener listener, Response.ErrorListener errorListener, String credentials) {
        final String cred = credentials;
        if (isNetworkAvailable()) {
            StringRequest request = new StringRequest(method, url, listener, errorListener) {
                @Override
                public Map<String, String> getHeaders() throws AuthFailureError {
                    Map<String, String> params = new HashMap<String, String>();
                    String auth = "Basic " + Base64.encodeToString(cred.getBytes(), Base64.NO_WRAP);
                    params.put("Authorization", auth);
                    return params;
                }
            };
            this.makeRequest(request);
        } else {
            errorListener.onErrorResponse(new VolleyError(ERR_NETWORK_UNAVAILABLE));
        }
    }

    public void makeJsonObjectRequest(int method, String url, JSONObject jsonObject, Response.Listener listener, Response.ErrorListener errorListener) {
        JsonObjectRequest request = new JsonObjectRequest(method, url, jsonObject, listener, errorListener);
        this.makeRequest(request);
    }

    public void makeJsonArrayRequest(int method, String url, JSONArray jsonArray, Response.Listener listener, Response.ErrorListener errorListener) {
        JsonArrayRequest request = new JsonArrayRequest(method, url, jsonArray, listener, errorListener);
        this.makeRequest(request);
    }

    public String getEndPoint() {
        String pref_baseUurl = Persistence.getInstance(mContext).getDatabaseBaseUrl();
        String pref_databasePackage = Persistence.getInstance(mContext).getDatabasePackage();
        String pref_servicePath = Persistence.getInstance(mContext).getServicePath();
        String endPoint = pref_baseUurl + "/" + pref_databasePackage + "/" + pref_servicePath;
        return endPoint;
    }
}
