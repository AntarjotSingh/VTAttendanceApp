package com.sap.vt.android.attendance_app.service;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

/**
 * Created by I327891 on 24-Jul-17.
 */

public class Persistence {

    private final static String PREF_USERNAME = "username";
    private final static String PREF_PASSWORD = "password";
    private final static String PREF_BASEURL = "baseurl";
    private final static String PREF_DATABASE_PACKAGE = "database_package";
    private final static String PREF_SERVICE_PATH = "service_path";
    private final static String PREF_DESIGNATION = "designation";
    private final static String PREF_HMAC_KEY = "hmacKey";
    private final static String PREF_SUPPORT_EMAIL = "supportEmail";

    private static Persistence mInstance;
    private Context mContext;

    private Persistence(Context context) {
        this.mContext = context;
    }

    public static Persistence getInstance(Context context) {
        if (mInstance == null) {
            mInstance = new Persistence(context);
        }
        return mInstance;
    }

    public boolean hasCredentials() {
        return (!this.getLoggedInUsername().equals("") && !this.getLoggedInPassword().equals(""));
    }

    public void setUsername(String username) {
        SharedPreferences.Editor sharedPrefEditor = PreferenceManager.getDefaultSharedPreferences(this.mContext).edit();
        sharedPrefEditor.putString(PREF_USERNAME, username).apply();
    }

    public void setPassword(String password) {
        SharedPreferences.Editor sharedPrefEditor = PreferenceManager.getDefaultSharedPreferences(this.mContext).edit();
        sharedPrefEditor.putString(PREF_PASSWORD, password).apply();
    }

    public void setDatabasePackage(String databasePackage) {
        SharedPreferences.Editor sharedPrefEditor = PreferenceManager.getDefaultSharedPreferences(this.mContext).edit();
        sharedPrefEditor.putString(PREF_DATABASE_PACKAGE, databasePackage).apply();
    }

    public void setDatabaseBaseUrl(String databaseBaseUrl) {
        SharedPreferences.Editor sharedPrefEditor = PreferenceManager.getDefaultSharedPreferences(this.mContext).edit();
        sharedPrefEditor.putString(PREF_BASEURL, databaseBaseUrl).apply();
    }

    public void setServicePath(String servicePath) {
        SharedPreferences.Editor sharedPrefEditor = PreferenceManager.getDefaultSharedPreferences(this.mContext).edit();
        sharedPrefEditor.putString(PREF_SERVICE_PATH, servicePath).apply();
    }

    public void setDesignation(String designation) {
        SharedPreferences.Editor sharedPrefEditor = PreferenceManager.getDefaultSharedPreferences(this.mContext).edit();
        sharedPrefEditor.putString(PREF_DESIGNATION, designation).apply();
    }

    public void setPrefHmacKey(String hmacKey) {
        SharedPreferences.Editor sharedPrefEditor = PreferenceManager.getDefaultSharedPreferences(this.mContext).edit();
        sharedPrefEditor.putString(PREF_HMAC_KEY, hmacKey).apply();
    }

    public void setSupportEmail(String supportEmail) {
        SharedPreferences.Editor sharedPrefEditor = PreferenceManager.getDefaultSharedPreferences(this.mContext).edit();
        sharedPrefEditor.putString(PREF_SUPPORT_EMAIL, supportEmail).apply();
    }


    public String getLoggedInUsername() {
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this.mContext);
        return sharedPreferences.getString(PREF_USERNAME, "");
    }

    public String getLoggedInPassword() {
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this.mContext);
        return sharedPreferences.getString(PREF_PASSWORD, "");
    }

    public String getDatabasePackage() {
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this.mContext);
        return sharedPreferences.getString(PREF_DATABASE_PACKAGE, "");
    }

    public String getDatabaseBaseUrl() {
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this.mContext);
        return sharedPreferences.getString(PREF_BASEURL, "");
    }

    public String getServicePath() {
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this.mContext);
        return sharedPreferences.getString(PREF_SERVICE_PATH, "");
    }

    public String getDesignation() {
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this.mContext);
        return sharedPreferences.getString(PREF_DESIGNATION, "");
    }

    public String getPrefHmacKey() {
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this.mContext);
        return sharedPreferences.getString(PREF_HMAC_KEY, "");
    }

    public String getPrefSupportEmail() {
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this.mContext);
        return sharedPreferences.getString(PREF_SUPPORT_EMAIL, "");
    }

    public void resetUserCredentials() {
        this.setUsername("");
        this.setPassword("");
        this.setDesignation("");
    }

    public void resetDatabaseDetails() {
        this.setServicePath("");
        this.setDatabasePackage("");
        this.setDatabaseBaseUrl("");
        this.setPrefHmacKey("");
        this.setSupportEmail("");
    }
}
