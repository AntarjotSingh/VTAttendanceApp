package com.sap.vt.android.attendance_app.ui.adapter;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.sap.vt.R;
import com.sap.vt.android.attendance_app.model.ClassSession;

import java.util.List;

/**
 * Created by I327891 on 11-Jul-17.
 */

public class SessionListAdapter extends RecyclerView.Adapter {

    private List<ClassSession> sessionList;

    public SessionListAdapter(List<ClassSession> sessionList) {
        this.sessionList = sessionList;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.layout_listitem_session, parent, false);
        return new SessionItemViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        ClassSession session = this.sessionList.get(position);
        SessionItemViewHolder lHolder = (SessionItemViewHolder) holder;
        lHolder.subjectTextView.setText(session.getSubject().getName());
        lHolder.batchTextView.setText(session.getBatch().getName());
    }

    @Override
    public int getItemCount() {
        return this.sessionList == null ? 0 : this.sessionList.size();
    }

    public void setSessionList(List<ClassSession> sessionList) {
        this.sessionList = sessionList;
        this.notifyDataSetChanged();
    }

    public class SessionItemViewHolder extends RecyclerView.ViewHolder {
        public TextView batchTextView, subjectTextView;

        public SessionItemViewHolder(View itemView) {
            super(itemView);
            batchTextView = (TextView) itemView.findViewById(R.id.list_item_session_batch);
            subjectTextView = (TextView) itemView.findViewById(R.id.list_item_session_subject);
        }
    }
}
