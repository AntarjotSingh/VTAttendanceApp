package com.sap.vt.android.attendance_app.ui.activity;

import android.app.Activity;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.transition.Fade;
import android.transition.TransitionInflater;
import android.transition.TransitionSet;
import android.view.View;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.sap.vt.R;
import com.sap.vt.android.attendance_app.manager.DataManager;
import com.sap.vt.android.attendance_app.manager.HashGenerator;
import com.sap.vt.android.attendance_app.service.Http;
import com.sap.vt.android.attendance_app.service.Persistence;
import com.sap.vt.android.attendance_app.ui.Banner;
import com.sap.vt.android.attendance_app.ui.fragment.ChangePasswordFragment;
import com.sap.vt.android.attendance_app.ui.fragment.FragmentListener;
import com.sap.vt.android.attendance_app.ui.fragment.LoginFragment;
import com.sap.vt.android.attendance_app.ui.fragment.SplashFragment;

import org.json.JSONObject;

import java.net.URLEncoder;
import java.util.Map;

/**
 * A login screen that offers login via email/password.
 */
public class LoginActivity extends BaseActivity implements FragmentListener, DataManager.OnSessionChangeListener {

    public static final long MOVE_DEFAULT_TIME = 1000;
    public static final long FADE_DEFAULT_TIME = 300;
    private String currentFragment;
    private String[] credentials;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        this.setFragment(SplashFragment.TAG);
        // getting database details


        this.getDatabaseUrl();

        DataManager.getInstance().addSessionChangeListener(this);
        this.initLogin();
    }

    @Override
    protected void onDestroy() {
        clearReferences();
        super.onDestroy();
        DataManager.getInstance().removeSessionChangeListener(this);
    }

    private void initLogin() {
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (DataManager.getInstance().hasCredentials()) {
                    DataManager.getInstance().requestUserLoginWithExistingCredentials();
                    if (getFragmentManager().findFragmentByTag(SplashFragment.TAG) != null) {
                        ((SplashFragment) getFragmentManager().findFragmentByTag(SplashFragment.TAG)).setIndeterminateProgressBarVisible(true);
                    }
                } else {
                    setFragment(LoginFragment.TAG);
                }
            }
        }, 2500);
    }

    private void setFragment(String fragmentTag) {
        this.currentFragment = fragmentTag;

        FragmentManager fManager = getFragmentManager();
        FragmentTransaction fTransaction = fManager.beginTransaction();
        Fragment fragment = null;

        switch (fragmentTag) {
            case SplashFragment.TAG:
                fragment = new SplashFragment();
                break;
            case LoginFragment.TAG:
                fragment = new LoginFragment();
                if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    TransitionSet enterTransitionSet = new TransitionSet();
                    enterTransitionSet.addTransition(TransitionInflater.from(this).inflateTransition(android.R.transition.move));
                    enterTransitionSet.setDuration(MOVE_DEFAULT_TIME);
                    enterTransitionSet.setStartDelay(FADE_DEFAULT_TIME);
                    fragment.setSharedElementEnterTransition(enterTransitionSet);

                    View logoImageView = ((SplashFragment) getFragmentManager().findFragmentByTag(SplashFragment.TAG)).getCircleImageView();
                    fTransaction.addSharedElement(logoImageView, logoImageView.getTransitionName());
                }
                break;
            case ChangePasswordFragment.TAG:
                fragment = new ChangePasswordFragment(credentials);
                if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    TransitionSet enterTransitionSet = new TransitionSet();
                    enterTransitionSet.addTransition(TransitionInflater.from(this).inflateTransition(android.R.transition.move));
                    enterTransitionSet.setDuration(MOVE_DEFAULT_TIME);
                    enterTransitionSet.setStartDelay(FADE_DEFAULT_TIME);
                    fragment.setSharedElementEnterTransition(enterTransitionSet);
                }
                break;
        }

        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Fade fade = new Fade();
            fade.setDuration(FADE_DEFAULT_TIME);
            if (this.currentFragment.equals(LoginFragment.TAG)) {
                fade.setStartDelay(MOVE_DEFAULT_TIME + FADE_DEFAULT_TIME);
                fragment.setEnterTransition(fade);
            } else {
                fragment.setExitTransition(fade);
            }
        }

        fTransaction.replace(R.id.login_fragmentContainer, fragment, fragmentTag);
        fTransaction.commit();
    }

    private void startMainActivity() {
        Intent intent = new Intent(this, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        this.startActivity(intent);
    }

    @Override
    public void onFragmentUpdate(String currentFragment, Object parameter) {
        switch (currentFragment) {
            case LoginFragment.TAG:
                if (parameter == null) {
                    ((LoginFragment) getFragmentManager().findFragmentByTag(LoginFragment.TAG)).setError(true);
                } else {
                    try {
                        credentials = (String[]) parameter;
                        this.showProgressDialog(R.string.logging_in);
                        final String encodedURLPassword = URLEncoder.encode(HashGenerator.getInstance().generateHash(credentials[1]), "UTF-8");
                        DataManager.getInstance().requestUserLogin(credentials[0], encodedURLPassword);
                    } catch (Exception e){
                        e.printStackTrace();
                        Banner.showErrorBanner("Error in data received");
                    }
                }
                break;
            case ChangePasswordFragment.TAG:
                if (parameter == null){
                } else {
                    String hashOldPassword = HashGenerator.getInstance().generateHash(credentials[1]);
                    String hashNewPassword = HashGenerator.getInstance().generateHash((String) parameter);
                    this.showProgressDialog(R.string.changing_password);
                    DataManager.getInstance().requestChangePassword(credentials[0], hashOldPassword, hashNewPassword);
                }
        }
    }

    @Override
    public void onLogin(boolean isSuccess, String error) {
        this.dismissDialog();
        if (isSuccess) {
            if (getFragmentManager().findFragmentByTag(LoginFragment.TAG) != null) {
                ((LoginFragment) getFragmentManager().findFragmentByTag(LoginFragment.TAG)).setError(false);
            } else if (getFragmentManager().findFragmentByTag(ChangePasswordFragment.TAG) != null) {
                ((ChangePasswordFragment) getFragmentManager().findFragmentByTag(ChangePasswordFragment.TAG)).setError(false);
            }
            this.startMainActivity();
        } else {
            if (error != null) {
                if (error.equals(Http.ERR_NETWORK_UNAVAILABLE)) {
                    this.showNoNetworkDialog();
                } else if (error.equals(DataManager.ERR_LOGIN_CREDENTIALS)) {
                    Banner.showErrorBanner(getResources().getString(R.string.error_invalid_credentials));
                    if (this.currentFragment.equals(LoginFragment.TAG)) {
                        ((LoginFragment) getFragmentManager().findFragmentByTag(LoginFragment.TAG)).setError(true);
                    } else {
                        this.setFragment(LoginFragment.TAG);
                    }
                } else if(error.equals(DataManager.ERR_RESET_PASSWORD_REQUIRED)){
                    this.setFragment(ChangePasswordFragment.TAG);
                    Banner.showErrorBanner(getResources().getString(R.string.error_reset_password));
                } else {
                    Banner.showErrorBanner(error);
                }
            } else {
                Banner.showErrorBanner("Unknown error!");
            }
        }

    }

    @Override
    public void onLogout() {

    }

    public void getDatabaseUrl(){
        String url = Http.DataBase_BaseUrl + Http.DataBase_EndPoint;
        String credentials = "Aditya:System123456789";
        Http.getInstance(getApplication().getApplicationContext()).makeStringRequestBasicAuth(Request.Method.GET, url, new Response.Listener() {
            @Override
            public void onResponse(Object response) {
                try {
                    JSONObject jsonObject = new JSONObject((String)(response));
                    String baseUrl = jsonObject.getString("BaseUrl");
                    String packageName = jsonObject.getString("PackageName");
                    String servicePath = jsonObject.getString("ServicePath");
                    String hmackKey = jsonObject.getString("HmacKey");
                    String supportEmail = jsonObject.getString("SupportEmail");
                    onDatabaseUrlReceived(baseUrl, packageName, servicePath, hmackKey, supportEmail);
                } catch (Exception e) {
                    onDatabaseUrlReceived("", "", "", "", "");
                    Banner.showErrorBanner(getResources().getString(R.string.error_parsing_json));
                }
            }

        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                onDatabaseUrlReceived("", "", "", "", "");
                Banner.showErrorBanner(getResources().getString(R.string.error_getting_databse_details) +"\n"+(error.networkResponse != null ? error.networkResponse.statusCode : "" ));
            }
        }, credentials);
    }

    public void onDatabaseUrlReceived(String baseUrl, String packageName, String servicePath, String hmackKey, String supportEmail){
        String pref_baseUurl = Persistence.getInstance(getApplication().getApplicationContext()).getDatabaseBaseUrl();
        String pref_databasePackage = Persistence.getInstance(getApplication().getApplicationContext()).getDatabasePackage();
        String pref_servicePath = Persistence.getInstance(getApplication().getApplicationContext()).getServicePath();
        String pref_hmacKey = Persistence.getInstance(getApplication().getApplicationContext()).getPrefHmacKey();
        String pref_supportEmail = Persistence.getInstance(getApplication().getApplicationContext()).getPrefSupportEmail();

        if (!baseUrl.equals(pref_baseUurl) || !packageName.equals(pref_databasePackage) || !servicePath.equals(pref_servicePath) || !hmackKey.equals(pref_hmacKey)) {
            Persistence.getInstance(getApplication().getApplicationContext()).resetUserCredentials();
            Persistence.getInstance(getApplication().getApplicationContext()).resetDatabaseDetails();
        }

        if(baseUrl != null && baseUrl.isEmpty() == false) {
            Persistence.getInstance(getApplication().getApplicationContext()).setDatabaseBaseUrl(baseUrl);
        }
        if(packageName != null && packageName.isEmpty() == false) {
            Persistence.getInstance(getApplication().getApplicationContext()).setDatabasePackage(packageName);
        }
        if(servicePath != null && servicePath.isEmpty() == false) {
            Persistence.getInstance(getApplication().getApplicationContext()).setServicePath(servicePath);
        }
        if(hmackKey != null && hmackKey.isEmpty() == false) {
            Persistence.getInstance(getApplication().getApplicationContext()).setPrefHmacKey(hmackKey);
        }
        if((supportEmail != null && supportEmail.isEmpty() == false) || !supportEmail.equals(pref_supportEmail) ) {
            Persistence.getInstance(getApplication().getApplicationContext()).setSupportEmail(supportEmail);
        }
    }
}

