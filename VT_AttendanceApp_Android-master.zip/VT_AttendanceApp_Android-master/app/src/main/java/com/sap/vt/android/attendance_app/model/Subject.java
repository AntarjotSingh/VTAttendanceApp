package com.sap.vt.android.attendance_app.model;

/**
 * Created by I327891 on 11-Jul-17.
 */

public class Subject {

    private final String uuid, name, code;

    public Subject(String uuid, String name, String code) {
        this.uuid = uuid;
        this.name = name;
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public String getCode() {
        return code;
    }

    public String getUuid() {
        return uuid;
    }
}
