package com.sap.vt.android.attendance_app.ui.adapter;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;
import com.sap.vt.R;
import com.sap.vt.android.attendance_app.model.Student;

import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public class ConfirmDialogStudentListAdapter extends RecyclerView.Adapter  {
    List<Student> studentList;
    private boolean isInMarkAbsenteeMode = true;

    public ConfirmDialogStudentListAdapter(List<Student> studentList) {
        this.studentList = studentList;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.layout_listitem_student_confirm_dialog, parent, false);
        return new ConfirmDialogStudentListAdapter.StudentItemViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        final Student student = this.studentList.get(position);

        holder.setIsRecyclable(false);
        ((ConfirmDialogStudentListAdapter.StudentItemViewHolder) holder).nameTextView.setText(student.getName());
        ((ConfirmDialogStudentListAdapter.StudentItemViewHolder) holder).BitsIDTextView.setText(student.getBITS_ID());
        if (student.getProfilePic() == null) {
            ((ConfirmDialogStudentListAdapter.StudentItemViewHolder) holder).profilePicImageView.setImageResource(R.drawable.ic_face_grey_600_48dp);
        } else {
            ((ConfirmDialogStudentListAdapter.StudentItemViewHolder) holder).profilePicImageView.setImageDrawable(student.getProfilePic());
        }
    }

    @Override
    public int getItemCount() {
        return this.studentList == null ? 0 : this.studentList.size();
    }

    public void setMarkAbsenteeMode(boolean markAbsenteeMode) {
        this.isInMarkAbsenteeMode = markAbsenteeMode;
    }

    public boolean isInMarkAbsenteeMode() {
        return this.isInMarkAbsenteeMode;
    }


    public List<Student> getStudentList() {
        if (!isInMarkAbsenteeMode) {
            for (Student presentee : this.studentList) {
                presentee.setAbsent(!presentee.isAbsent());
            }
        }
        return this.studentList;
    }

    public void setStudentList(List<Student> studentList) {
        this.studentList = studentList;
        this.notifyDataSetChanged();
    }

    public class StudentItemViewHolder extends RecyclerView.ViewHolder{
        TextView nameTextView, BitsIDTextView;
        CheckBox absentCheckbox;
        CircleImageView profilePicImageView;

        Context context;

        public StudentItemViewHolder(View itemView) {
            super(itemView);

            context = itemView.getContext();

            nameTextView = (TextView) itemView.findViewById(R.id.student_list_item_name);
            BitsIDTextView = (TextView) itemView.findViewById(R.id.student_list_item_bits_id);
            profilePicImageView = (CircleImageView) itemView.findViewById(R.id.student_list_item_profile_pic);
        }
    }
}
