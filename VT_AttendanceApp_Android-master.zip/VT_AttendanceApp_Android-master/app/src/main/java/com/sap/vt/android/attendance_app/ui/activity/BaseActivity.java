package com.sap.vt.android.attendance_app.ui.activity;

import android.app.Activity;
import android.support.annotation.NonNull;
import android.support.annotation.StringRes;
import android.support.v7.app.AppCompatActivity;

import com.afollestad.materialdialogs.DialogAction;
import com.afollestad.materialdialogs.MaterialDialog;
import com.sap.vt.R;
import com.sap.vt.android.attendance_app.manager.DataManager;
import com.sap.vt.android.attendance_app.manager.MarkAttendanceDataManager;

import java.util.ArrayList;

/**
 * Created by I327891 on 16-Jul-17.
 */

public class BaseActivity extends AppCompatActivity {

    private MaterialDialog mMaterialDialog;

    public void showProgressDialog(int stringId) {
        if (this.mMaterialDialog != null && this.mMaterialDialog.isShowing() && this.mMaterialDialog.isIndeterminateProgress()) {
            this.mMaterialDialog.setContent(stringId);
        } else {
            this.mMaterialDialog = new MaterialDialog.Builder(this)
                    .content(stringId)
                    .progressIndeterminateStyle(true)
                    .progress(true, 0)
                    .cancelable(false)
                    .build();
            this.mMaterialDialog.show();
        }
    }

    public void dismissDialog() {
        if (this.mMaterialDialog != null) {
            this.mMaterialDialog.dismiss();
            this.mMaterialDialog = null;
        }
    }

    public void showDialog(@StringRes int titleStringId, @StringRes int messageStringId, @StringRes int positiveButtonStringId, @StringRes int negativeButtonStringId, MaterialDialog.SingleButtonCallback listener) {
        if (this.mMaterialDialog != null && this.mMaterialDialog.isShowing() && !this.mMaterialDialog.isIndeterminateProgress()) {
            this.mMaterialDialog.dismiss();
        }

        MaterialDialog.Builder materialDialogBuilder = new MaterialDialog.Builder(this);

        materialDialogBuilder.title(titleStringId)
                .positiveText(positiveButtonStringId)
                .onAny(listener);
        if (messageStringId != -1) {
            materialDialogBuilder.content(messageStringId);
        }
        if (negativeButtonStringId != -1) {
            materialDialogBuilder.negativeText(negativeButtonStringId);
        }
        this.mMaterialDialog = materialDialogBuilder.build();
        this.mMaterialDialog.show();
    }

    public void showDialog(int titleStringId, int positiveButtonStringId, int negativeButtonStringId, MaterialDialog.SingleButtonCallback listener) {
        this.showDialog(titleStringId, -1, positiveButtonStringId, negativeButtonStringId, listener);
    }

    public void showMessageDialog(int titleStringId, int messageStringId, int positiveButtonStringId, MaterialDialog.SingleButtonCallback listener) {
        this.showDialog(titleStringId, messageStringId, positiveButtonStringId, -1, listener);
    }

    public void showListDialog(int titleStringId, ArrayList<String> items, MaterialDialog.ListCallback listener) {
        if (this.mMaterialDialog != null && this.mMaterialDialog.isShowing() && !this.mMaterialDialog.isIndeterminateProgress()) {
            this.mMaterialDialog.dismiss();
        }

        this.mMaterialDialog = new MaterialDialog.Builder(this)
                .title(titleStringId)
                .items(items)
                .itemsCallback(listener)
                .build();
        this.mMaterialDialog.show();
    }

    public void showNoNetworkDialog() {
        this.mMaterialDialog = new MaterialDialog.Builder(this)
                .title(R.string.error_fetching_data)
                .content(R.string.no_network_content)
                .positiveText(R.string.ok)
                .onAny(new MaterialDialog.SingleButtonCallback() {
                    @Override
                    public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                        onDestroy();
                        System.exit(0);
                    }
                })
                .build();
        this.mMaterialDialog.show();
    }

    protected void onResume() {
        super.onResume();
        DataManager.getInstance().getApplication().setCurrentActivity(this);
    }
    protected void onPause() {
        clearReferences();
        super.onPause();
    }

    protected void clearReferences(){
        Activity currActivity = DataManager.getInstance().getApplication().getCurrentActivity();
        if (this.equals(currActivity))
            DataManager.getInstance().getApplication().setCurrentActivity(null);
    }
}
