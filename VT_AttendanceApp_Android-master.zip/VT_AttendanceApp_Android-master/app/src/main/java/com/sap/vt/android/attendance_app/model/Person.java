package com.sap.vt.android.attendance_app.model;

import android.graphics.drawable.Drawable;

/**
 * Created by I327891 on 11-Jul-17.
 */

class Person {
    private final String ID, name, email, phoneNumber;

    private Drawable profilePic;

    Person(String id, String name, String email, String phoneNumber) {
        ID = id;
        this.name = name;
        this.email = email;
        this.phoneNumber = phoneNumber;
    }

    public String getID() {
        return ID;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public Drawable getProfilePic() {
        return profilePic;
    }

    public void setProfilePic(Drawable profilePic) {
        this.profilePic = profilePic;
    }
}
