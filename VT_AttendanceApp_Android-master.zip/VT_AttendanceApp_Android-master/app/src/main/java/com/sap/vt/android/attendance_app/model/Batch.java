package com.sap.vt.android.attendance_app.model;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by I327891 on 11-Jul-17.
 */

public class Batch {
    private final String ID, name;
    private List<Student> studentList;
    private int noOfStudents;

    public Batch(String id, String name) {
        this.ID = id;
        this.name = name;
        this.studentList = new ArrayList<>();
    }

    public String getUUID() {
        return ID;
    }

    public String getName() {
        return name;
    }

    public String getYear() {
        return this.name.split(" ")[0];
    }

    public String getType() {
        return this.name.split(" ")[1];
    }

    public List<Student> getStudentList() {
        return studentList;
    }

    public void setStudentList(List<Student> studentList) {
        this.studentList = studentList;
        this.noOfStudents = this.studentList.size();
    }

    public int getNoOfStudents() {
        return noOfStudents;
    }
}
