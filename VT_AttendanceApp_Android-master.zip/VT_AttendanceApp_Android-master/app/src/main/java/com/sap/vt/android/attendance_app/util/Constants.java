package com.sap.vt.android.attendance_app.util;

public class Constants {
    public static final String packageWhatsApp = "com.whatsapp";
    public static final String packageOutlook = "com.microsoft.office.outlook";
    public static final String packageTeams = "com.microsoft.teams";
}
