package com.sap.vt.android.attendance_app.ui.fragment;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Fragment;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.support.design.widget.TextInputEditText;
import android.support.design.widget.TextInputLayout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.sap.vt.R;
import com.sap.vt.android.attendance_app.manager.DataManager;
import com.sap.vt.android.attendance_app.manager.HashGenerator;
import com.sap.vt.android.attendance_app.service.Persistence;
import com.sap.vt.android.attendance_app.ui.Banner;
import com.sap.vt.android.attendance_app.ui.activity.LoginActivity;
import com.sap.vt.android.attendance_app.ui.activity.MainActivity;

import java.net.URLEncoder;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@SuppressLint("ValidFragment")
public class ChangePasswordFragment  extends Fragment implements View.OnClickListener {

    public final static String TAG = "ChangePassword";

    Button chngPassButton;
    TextInputLayout oldPassTextInputLayout, newPassTextInputLayout, confrmPassTextInputLayout;
    TextInputEditText oldPassEditText, newPassEditText, confrmPassEditText;
    private static final String PASSWORD_PATTERN = "((?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%]).{6,20})";
    private Pattern pattern;
    private Matcher matcher;
    private String newPassword, oldPassword;

    FragmentListener mListener;

    public String[] credentials = new String[0];

    @SuppressLint("ValidFragment")
    public ChangePasswordFragment(String[] credentials){
        this.credentials = credentials;
    }

    @SuppressLint("ValidFragment")
    public ChangePasswordFragment(){
    }

    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_password_change, container, false);
        oldPassEditText = (TextInputEditText) view.findViewById(R.id.oldPassword);
        oldPassTextInputLayout = (TextInputLayout) view.findViewById(R.id.chngPasswordLayoutOldPass);
        newPassEditText = (TextInputEditText) view.findViewById(R.id.newPassword);
        newPassTextInputLayout = (TextInputLayout) view.findViewById(R.id.chngPasswordLayoutNewPass);
        confrmPassEditText = (TextInputEditText) view.findViewById(R.id.confirmPassword);
        confrmPassTextInputLayout = (TextInputLayout) view.findViewById(R.id.chngPasswordLayoutConfrmPass);
        chngPassButton = (Button) view.findViewById(R.id.chngPasswordBtn);
        chngPassButton.setOnClickListener(this);
        return view;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof LoginActivity || context instanceof MainActivity) {
            this.mListener = (FragmentListener) getActivity();
        }
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        if (activity instanceof LoginActivity || activity instanceof MainActivity) {
            this.mListener = (FragmentListener) getActivity();
        }
    }

    private boolean isValidOldPassword() {
        oldPassword = oldPassEditText.getText().toString();
        String actualOldPassword = "";
        if(credentials.length >= 2){
            actualOldPassword = credentials[1];
        } else {
            try {
                actualOldPassword = Persistence.getInstance(DataManager.getInstance().getApplication().getApplicationContext()).getLoggedInPassword();
                oldPassword = URLEncoder.encode(HashGenerator.getInstance().generateHash(oldPassword), "UTF-8");
            } catch(Exception e){
                e.printStackTrace();
                Banner.showErrorBanner("Error in data received");
            }
        }
        return actualOldPassword.equals(oldPassword) ? true : false ;
    }

    private boolean confirmNewPassword() {
        newPassword = newPassEditText.getText().toString();
        String confirmPassword = confrmPassEditText.getText().toString();
        return ((newPassword.equals(confirmPassword))) ? true : false;
    }

    public void setError(boolean isValid) {

        if (!isValidOldPassword() ) {
            oldPassTextInputLayout.setError(!isValid ? null : getResources().getString(R.string.error_incorrect_password));
        }
        if ((oldPassword.equals(newPassword))) {
            newPassTextInputLayout.setError(!isValid ? null : getResources().getString(R.string.error_newPassword_matches_oldPassword ));
        } else {
            if (!validatePassword()) {
                newPassTextInputLayout.setError(!isValid ? null : getResources().getString(R.string.error_password_validation));
            }
            if (!confirmNewPassword()) {
                confrmPassTextInputLayout.setError(!isValid ? null : getResources().getString(R.string.error_password_not_match));
            }
        }
    }

    //must contains one digit from 0-9
    //must contains one lowercase characters
    //must contains one uppercase characters
    //must contains one special symbols in the list "@#$%"
    //length at least 6 characters and maximum of 20
    private boolean validatePassword(){
        pattern = Pattern.compile(PASSWORD_PATTERN);
        matcher = pattern.matcher(newPassword);
        return matcher.matches();
    }

    @Override
    public void onClick(View v) {
        if (v == chngPassButton) {
            if (isValidOldPassword() && confirmNewPassword() && validatePassword() && !(oldPassword.equals(newPassword))) {
                this.mListener.onFragmentUpdate(TAG, newPassword);
            } else {
                this.mListener.onFragmentUpdate(TAG, null);
                this.setError(true);
            }
        }
    }
}
