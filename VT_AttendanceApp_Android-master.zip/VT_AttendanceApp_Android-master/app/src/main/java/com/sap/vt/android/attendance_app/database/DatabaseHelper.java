package com.sap.vt.android.attendance_app.database;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.sap.vt.android.attendance_app.model.Student;

import java.util.ArrayList;

/**
 * Created by I353729 on 06/12/2019.
 */

public class DatabaseHelper extends SQLiteOpenHelper {
    private String TABLE_NAME;
    private Context context;
    private String bitsId_col = "BITS_ID";
    private String uuid_col = "UUID";
    private String email_col = "EMAIL";
    private String phNo_col = "PHONE_NUMBER";
    private String empId_col = "EMPID";
    private String name_col = "NAME";
    private String isAbsent_col = "IS_ABSENT";

    public DatabaseHelper(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    public DatabaseHelper(Context context, String TABLE_NAME) {
        super(context, TABLE_NAME, null, 1);
        this.context = context;
        this.TABLE_NAME = TABLE_NAME;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table if not EXISTS " + TABLE_NAME + " (UUID TEXT PRIMARY KEY, BITS_ID TEXT, IS_ABSENT INTEGER, EMPID TEXT, NAME TEXT, PHONE_NUMBER TEXT, EMAIL TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS "+TABLE_NAME);
        onCreate(db);
    }

    public ArrayList<Student> getAttendanceData() {
        ArrayList<Student> arrayList = new ArrayList<Student>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("select * from "+TABLE_NAME,null);
        if (cursor.moveToFirst()){
            while(!cursor.isAfterLast()){
                String bitsId = cursor.getString(cursor.getColumnIndex(bitsId_col));
                String uuid = cursor.getString(cursor.getColumnIndex(uuid_col));
                String email = cursor.getString(cursor.getColumnIndex(email_col));
                String phNp = cursor.getString(cursor.getColumnIndex(phNo_col));
                String empId = cursor.getString(cursor.getColumnIndex(empId_col));
                String name = cursor.getString(cursor.getColumnIndex(name_col));
                Boolean isAbsent = cursor.getInt(cursor.getColumnIndex(isAbsent_col)) == 1 ? true : false;

                Student student = new Student(uuid, empId, bitsId, name, email, phNp);
                student.setAbsent(isAbsent);
                arrayList.add(student);
                cursor.moveToNext();
            }
        }
        cursor.close();
        return arrayList;
    }

    private void insertAttendanceData(ArrayList<Student> students) {
        SQLiteDatabase db = this.getWritableDatabase();
        for (Student student : students) {
            ContentValues contentValues = new ContentValues();
            contentValues.put(bitsId_col,student.getBITS_ID());
            contentValues.put(uuid_col,student.getUuid());
            contentValues.put(isAbsent_col,student.isAbsent() == true ? 1 : 0);
            contentValues.put(email_col, student.getEmail());
            contentValues.put(empId_col, student.getID());
            contentValues.put(name_col, student.getName());
            contentValues.put(phNo_col, student.getPhoneNumber());
            long result = db.insert(TABLE_NAME,null ,contentValues);
        }
    }

    public void updateAttendanceData(ArrayList<Student> students) {
        SQLiteDatabase db = this.getWritableDatabase();
        if(checkIfTableExists()) {
            ContentValues contentValues = new ContentValues();
            for (Student student : students) {
                contentValues.put(bitsId_col,student.getBITS_ID());
                contentValues.put(uuid_col,student.getUuid());
                contentValues.put(isAbsent_col,student.isAbsent() == true ? 1 : 0);
                contentValues.put(email_col, student.getEmail());
                contentValues.put(empId_col, student.getID());
                contentValues.put(name_col, student.getName());
                contentValues.put(phNo_col, student.getPhoneNumber());
                db.update(TABLE_NAME, contentValues, uuid_col + " = ?", new String[]{student.getUuid()});
            }
        } else {
            insertAttendanceData(students);
        }
    }

    public boolean checkIfTableExists(){
        SQLiteDatabase db = this.getWritableDatabase();
        String sql = "SELECT name FROM sqlite_master WHERE type='table' AND name='"+TABLE_NAME+"'";
        Cursor mCursor = db.rawQuery(sql, null);
        if (mCursor.getCount() > 0) {
            ArrayList<Student> students = getAttendanceData();
            if (students.size() > 0) {
                return true;
            } else {
                return false;
            }
        }
        mCursor.close();
        return false;
    }
}
