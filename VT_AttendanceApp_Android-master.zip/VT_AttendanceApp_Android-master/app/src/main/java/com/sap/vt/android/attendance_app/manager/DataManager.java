package com.sap.vt.android.attendance_app.manager;

import android.app.Activity;
import android.app.Application;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.sap.vt.android.attendance_app.AttendanceApplication;
import com.sap.vt.android.attendance_app.service.Http;
import com.sap.vt.android.attendance_app.service.Persistence;
import com.sap.vt.android.attendance_app.ui.Banner;

import org.json.JSONObject;

import java.net.URLEncoder;
import java.util.ArrayList;

import static com.sap.vt.android.attendance_app.service.Http.ERR_NETWORK_UNAVAILABLE;

/**
 * Created by I327891 on 17-Jul-17.
 */

public class DataManager {

    public static final String ERR_LOGIN_CREDENTIALS = "ERR_LOGIN_CREDENTIALS";
    public static final String ERR_RESET_PASSWORD_REQUIRED= "ERR_RESET_PASSWORD_REQUIRED";

    private static DataManager mInstance;
    private AttendanceApplication mApplication;
    private ArrayList<OnSessionChangeListener> mSessionChangeListeners;

    public DataManager() {
        mSessionChangeListeners = new ArrayList<>();
    }

    public static DataManager getInstance() {
        if (mInstance == null) {
            mInstance = new DataManager();
        }
        return mInstance;
    }

    public AttendanceApplication getApplication() {
        return this.mApplication;
    }

    public void setApplication(Application application) {
        this.mApplication = (AttendanceApplication) application;
    }

    public void addSessionChangeListener(OnSessionChangeListener listener) {
        mSessionChangeListeners.add(listener);
    }

    public void removeSessionChangeListener(OnSessionChangeListener listener) {
        mSessionChangeListeners.remove(listener);
    }

    public void resetData() {
        Persistence.getInstance(getApplication().getApplicationContext()).resetUserCredentials();
    }

    public boolean hasCredentials() {
        return Persistence.getInstance(this.mApplication.getApplicationContext()).hasCredentials();
    }

    public void requestUserLoginWithExistingCredentials() {
        this.requestUserLogin(Persistence.getInstance(this.mApplication.getApplicationContext()).getLoggedInUsername(), Persistence.getInstance(this.mApplication.getApplicationContext()).getLoggedInPassword());
    }

    public void requestUserLogin(final String username, final String password) {
        try {
            String url = Http.getInstance(getApplication().getApplicationContext()).getEndPoint() + "/GetFacultyDetail.xsjs?email=" + username + "&password=" + password;
            Http.getInstance(this.mApplication.getApplicationContext()).makeStringRequest(Request.Method.GET, url, new Response.Listener() {
                @Override
                public void onResponse(Object response) {
                    try {
                        JSONObject responseObj = new JSONObject((String) response);
                        int responseSuccess = responseObj.getInt("result");
                        if (responseSuccess == 1) {
                            JSONObject facultyObj = responseObj.getJSONObject("FacultyDetail");
                            if (facultyObj.has("EmployeeNumber")) {
                                updateListenersOnLogin(true, "Login success");
                                Persistence.getInstance(mApplication.getApplicationContext()).setUsername(facultyObj.getString("Email"));
                                Persistence.getInstance(mApplication.getApplicationContext()).setPassword(password);
                                Persistence.getInstance(mApplication.getApplicationContext()).setDesignation(facultyObj.getString("Designation"));
                            } else {
                                updateListenersOnLogin(false, ERR_LOGIN_CREDENTIALS);
                            }
                        } else if (responseSuccess == 2) {
                            updateListenersOnLogin(false, ERR_RESET_PASSWORD_REQUIRED);
                        } else {
                            updateListenersOnLogin(false, ERR_LOGIN_CREDENTIALS);
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                        Banner.showErrorBanner("Error in data received");
                        updateListenersOnLogin(false, "Error in received data");
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    updateListenersOnLogin(false, ERR_NETWORK_UNAVAILABLE);
                }
            });
        } catch (Exception e){
            e.printStackTrace();
            Banner.showErrorBanner("Error in data received");
            updateListenersOnLogin(false, "Error in received data");
        }
    }

    public void requestChangePassword(final String email, final String oldPassword, final String newPassword) {
        try {
            String url = Http.getInstance(getApplication().getApplicationContext()).getEndPoint() + "/PasswordChange.xsjs";
            JSONObject payload = new JSONObject();
            payload.put("email", email);
            payload.put("oldPassword", oldPassword);
            payload.put("newPassword", newPassword);
                Http.getInstance(getApplication().getApplicationContext()).makeJsonObjectRequest(Request.Method.POST, url, payload, new Response.Listener() {
                @Override
                public void onResponse(Object response) {
                    try {
                        JSONObject responseObj = (JSONObject) response;
                        int responseSuccess = responseObj.getInt("statusCode");
                        if (responseSuccess == 200) {
                            final String encodedURLPassword = URLEncoder.encode(newPassword, "UTF-8");
                            requestUserLogin(email, encodedURLPassword);
                        } else {
                            updateListenersOnLogin(false, ERR_LOGIN_CREDENTIALS);
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                        Banner.showErrorBanner("Error in data received");
                        updateListenersOnLogin(false, "Error in received data");
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Banner.showErrorBanner(error.getMessage());
                    updateListenersOnLogin(false, "Error in received data");
                }
            });

        } catch (Exception e){
            e.printStackTrace();
            Banner.showErrorBanner("Error in data received");
            updateListenersOnLogin(false, "Error in received data");
        }
    }

    public void requestUserLogout() {
        Persistence.getInstance(this.mApplication.getApplicationContext()).resetUserCredentials();
        this.updateListenersOnLogout();
    }

    private void updateListenersOnLogin(boolean isSuccess, String message) {
        for (OnSessionChangeListener listener : mSessionChangeListeners) {
            listener.onLogin(isSuccess, message);
        }
    }

    private void updateListenersOnLogout() {
        for (OnSessionChangeListener listener : mSessionChangeListeners) {
            listener.onLogout();
        }
    }

    public interface OnSessionChangeListener {
        void onLogin(boolean isSuccess, String message);

        void onLogout();
    }
}