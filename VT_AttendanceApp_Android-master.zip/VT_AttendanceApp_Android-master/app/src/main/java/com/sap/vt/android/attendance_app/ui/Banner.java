package com.sap.vt.android.attendance_app.ui;

import android.app.Activity;
import android.graphics.Color;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.androidadvance.topsnackbar.TSnackbar;
import com.sap.vt.R;
import com.sap.vt.android.attendance_app.manager.DataManager;

public class Banner extends Activity {

    public static void showErrorBanner(String textToBeDisplayed) {
        Activity activity = DataManager.getInstance().getApplication().getCurrentActivity();
        TSnackbar snackbar = TSnackbar.make(activity.findViewById(R.id.main_toolbar), textToBeDisplayed, TSnackbar.LENGTH_SHORT);
        snackbar.setActionTextColor(Color.WHITE);
        View snackbarView = snackbar.getView();
        TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
        textView.setTextColor(Color.parseColor("#E9F2EB"));
        displaySnackBarWithBottomMargin(snackbar, 50,8, R.drawable.error_banner);
    }

    public static void showBanner(String textToBeDisplayed) {
        TSnackbar snackbar = TSnackbar.make(DataManager.getInstance().getApplication().getCurrentActivity().findViewById(R.id.main_toolbar), textToBeDisplayed, TSnackbar.LENGTH_SHORT);
        snackbar.setActionTextColor(Color.WHITE);
        View snackbarView = snackbar.getView();
        TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
        textView.setTextColor(Color.parseColor("#E9F2EB"));
        displaySnackBarWithBottomMargin(snackbar, 50,8, R.drawable.normal_banner);
    }

    public static void showSuccessBanner(String textToBeDisplayed) {
        TSnackbar snackbar = TSnackbar.make(DataManager.getInstance().getApplication().getCurrentActivity().findViewById(R.id.main_toolbar), textToBeDisplayed, TSnackbar.LENGTH_SHORT);
        snackbar.setActionTextColor(Color.WHITE);
        View snackbarView = snackbar.getView();
        TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
        textView.setTextColor(Color.parseColor("#E9F2EB"));
        displaySnackBarWithBottomMargin(snackbar, 50, 8, R.drawable.success_banner);
    }

    public static void displaySnackBarWithBottomMargin(TSnackbar snackbar, int sideMargin, int topMargin, int shape) {
        TypedValue tv = new TypedValue();
        int actionBarHeight = 0;
        if (DataManager.getInstance().getApplication().getApplicationContext().getTheme().resolveAttribute(android.R.attr.actionBarSize, tv, true)) {
            actionBarHeight = TypedValue.complexToDimensionPixelSize(tv.data, DataManager.getInstance().getApplication().getApplicationContext().getResources().getDisplayMetrics());
        }
        final View snackBarView = snackbar.getView();
        final ViewGroup.MarginLayoutParams params = (ViewGroup.MarginLayoutParams) snackBarView.getLayoutParams();

        params.setMargins(params.leftMargin + sideMargin,
                params.topMargin + actionBarHeight,
                params.rightMargin + sideMargin,
                params.bottomMargin);
        snackBarView.setLayoutParams(params);
        snackBarView.setBackgroundResource(shape);
        snackbar.setDuration(TSnackbar.LENGTH_SHORT);
        snackbar.show();
    }
}
