package com.sap.vt.android.attendance_app.model;

/**
 * Created by I327891 on 11-Jul-17.
 */

public class Faculty extends Person {
    private String username, password;

    public Faculty(String id, String name, String email, String phoneNumber) {
        super(id, name, email, phoneNumber);
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
