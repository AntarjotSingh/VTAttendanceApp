package com.sap.vt.android.attendance_app.model;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.Comparator;

/**
 * Created by I327891 on 11-Jul-17.
 */

public class Student extends Person {
    private final String BITS_ID, uuid;
    private boolean isAbsent;

    public Student(String uuid, String empId, String BITSID, String name, String email, String phoneNumber) {
        super(empId, name, email, phoneNumber);
        this.uuid = uuid;
        this.BITS_ID = BITSID;
        this.isAbsent = false;
    }

    public String getUuid() {
        return uuid;
    }

    public String getBITS_ID() {
        return BITS_ID;
    }

    public boolean isAbsent() {
        return isAbsent;
    }

    public void setAbsent(boolean absent) {
        isAbsent = absent;
    }
}

