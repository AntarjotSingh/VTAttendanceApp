package com.sap.vt.android.attendance_app.ui.activity;

import android.os.Bundle;
import android.support.v4.view.MenuItemCompat;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SearchView;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuInflater;

import com.sap.vt.R;
import com.sap.vt.android.attendance_app.manager.MarkAttendanceDataManager;
import com.sap.vt.android.attendance_app.model.ClassSession;
import com.sap.vt.android.attendance_app.model.Student;
import com.sap.vt.android.attendance_app.ui.adapter.StudentListAdapter;

import java.util.ArrayList;
import java.util.List;

public class SearchActivity extends BaseActivity implements SearchView.OnQueryTextListener, MarkAttendanceDataManager.OnClassSessionDataListener {

    public static final String TAG = "Activity.Search";

    StudentListAdapter mStudentListAdapter;
    ArrayList<Student> mStudentList;

    ClassSession classSessionModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);
        Toolbar toolbar = (Toolbar) findViewById(R.id.main_toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        RecyclerView studentRecyclerView = (RecyclerView) findViewById(R.id.search_recycler_view);
        mStudentListAdapter = new StudentListAdapter(null);
        studentRecyclerView.setAdapter(mStudentListAdapter);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(this);
        studentRecyclerView.setLayoutManager(mLayoutManager);
        studentRecyclerView.setItemAnimator(new DefaultItemAnimator());

        MarkAttendanceDataManager.getInstance().addSessionModelListener(this);
        MarkAttendanceDataManager.getInstance().requestSessionModelList(false);
    }

    @Override
    protected void onDestroy() {
        clearReferences();
        super.onDestroy();
        MarkAttendanceDataManager.getInstance().removeSessionModelListener(this);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.search, menu);

        final SearchView searchView = (SearchView) MenuItemCompat.getActionView(menu.findItem(R.id.search));
        searchView.setOnQueryTextListener(this);
        return true;
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (this.classSessionModel != null) {
            this.classSessionModel.updateStudentList(this.mStudentListAdapter.getStudentList());
            MarkAttendanceDataManager.getInstance().updateSession(this.classSessionModel);
        }
    }

    @Override
    public boolean onQueryTextSubmit(String query) {
        this.searchString(query);
        return true;
    }

    @Override
    public boolean onQueryTextChange(String newText) {
        this.searchString(newText);
        return true;
    }

    private void searchString(String query) {
        if (!query.equals("")) {
            ArrayList<Student> filteredStudents = new ArrayList<>();
            for (Student student : this.mStudentList) {
                if (student.getName().toLowerCase().contains(query.toLowerCase())) {
                    filteredStudents.add(student);
                }
            }
            this.mStudentListAdapter.setStudentList(filteredStudents);
        } else {
            this.mStudentListAdapter.setStudentList(this.mStudentList);
        }
    }

    @Override
    public void onClassSessionListAvailable(List<ClassSession> sessionList) {
        this.classSessionModel = sessionList.get(getIntent().getExtras().getInt(SearchActivity.TAG));
        this.mStudentList = (ArrayList) this.classSessionModel.getBatch().getStudentList();
        this.mStudentListAdapter.setStudentList(this.mStudentList);
    }

    @Override
    public void onClassSessionListUpdated(boolean status, String error) {

    }
}
