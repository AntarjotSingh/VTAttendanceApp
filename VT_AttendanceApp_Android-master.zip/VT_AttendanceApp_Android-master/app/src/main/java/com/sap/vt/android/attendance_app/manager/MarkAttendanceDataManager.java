package com.sap.vt.android.attendance_app.manager;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.sap.vt.android.attendance_app.model.Batch;
import com.sap.vt.android.attendance_app.model.ClassSession;
import com.sap.vt.android.attendance_app.model.Faculty;
import com.sap.vt.android.attendance_app.model.Student;
import com.sap.vt.android.attendance_app.model.StudentComparotar;
import com.sap.vt.android.attendance_app.model.Subject;
import com.sap.vt.android.attendance_app.service.Http;
import com.sap.vt.android.attendance_app.service.Persistence;
import com.sap.vt.android.attendance_app.ui.Banner;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

/**
 * Created by I327891 on 11-Jul-17.
 */

public class MarkAttendanceDataManager extends DataManager {

    private static MarkAttendanceDataManager mInstance;


    private ArrayList<OnClassSessionDataListener> mClassSessionDataListeners;
    private ArrayList<OnFacultyDataListener> mFacultyDataListeners;

    private ArrayList<ClassSession> sessionModelList;
    private HashMap<String, Integer> maxSessionNumberHashMap = new HashMap<>();
    private Faculty facultyModel;
    private int currentSessionNumber;


    private MarkAttendanceDataManager() {
        super();
        mClassSessionDataListeners = new ArrayList<>();
        mFacultyDataListeners = new ArrayList<>();
        currentSessionNumber = 1;
    }

    public static MarkAttendanceDataManager getInstance() {
        if (mInstance == null) {
            mInstance = new MarkAttendanceDataManager();
        }
        return mInstance;
    }

    public void addSessionModelListener(OnClassSessionDataListener listener) {
        mClassSessionDataListeners.add(listener);
    }

    public void removeSessionModelListener(OnClassSessionDataListener listener) {
        mClassSessionDataListeners.remove(listener);
    }

    public void addFacultyModelListener(OnFacultyDataListener listener) {
        mFacultyDataListeners.add(listener);
    }

    public void removeFacultyModelListener(OnFacultyDataListener listener) {
        mFacultyDataListeners.remove(listener);
    }

    public void resetData() {
        this.maxSessionNumberHashMap.clear();
        this.sessionModelList = null;
        this.facultyModel = null;
        currentSessionNumber = 1;
    }

    public ArrayList<String> getListOfSessionNumbers(ClassSession classSessionModel) {
        ArrayList<String> sessionList = new ArrayList<>();
        for (int i = 1; i <= classSessionModel.getMaxSessionNumber(); i++) {
            sessionList.add(String.valueOf(i));
        }
        return sessionList;
    }

    private void requestBatchList() {
        String username = Persistence.getInstance(getApplication().getApplicationContext()).getLoggedInUsername();
        String url = Http.getInstance(getApplication().getApplicationContext()).getEndPoint() + "/GetBatchList.xsjs?email=" + username;
        Http.getInstance(getApplication().getApplicationContext()).makeStringRequest(Request.Method.GET, url, new Response.Listener() {
            @Override
            public void onResponse(Object response) {
                try {
                    JSONObject responseObj = new JSONObject((String) response);
                    int responseSuccess = responseObj.getInt("result");
                    if (responseSuccess == 1) {
                        JSONArray batchListObj = responseObj.getJSONArray("BatchList");
                        sessionModelList = new ArrayList<>();
                        if (batchListObj.length() > 0) {
                            for (int i = 0; i < batchListObj.length(); i++) {
                                JSONObject batchObj = batchListObj.getJSONObject(i);
                                String subjectCode = batchObj.getString("SubjectCode");
                                String subjectName = batchObj.getString("SubjectName");
                                String subjectUUID = batchObj.getString("SubjectUUID");
                                int semester = batchObj.getInt("Semester");
                                String batchName = batchObj.getString("BatchName");
                                String batchID = batchObj.getString("BatchUUID");
                                Batch batch = new Batch(batchID, batchName);
                                Subject subject = new Subject(subjectUUID, subjectName, subjectCode);
                                ClassSession classSession = new ClassSession(i, String.valueOf(i), subject, currentSessionNumber, semester, ClassSession.Status.UNMARKED, false);
                                classSession.setBatch(batch);
                                sessionModelList.add(classSession);

                                //In Order to check Attendance marked by CR for the last Session calling API to get data from AttendanceCR
                                if(maxSessionNumberHashMap.get(subjectUUID) == null || maxSessionNumberHashMap.get(subjectUUID) == currentSessionNumber){
                                    requestSessionDetailsCR(classSession);
                                } else {
                                    requestSessionDetails(classSession);
                                }
                            }
                        } else {
                            updateListenersOnSessionListAvailable(sessionModelList);
                        }
                    } else {
                        getApplication().resetData();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    Banner.showErrorBanner("Error in data received");
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Banner.showErrorBanner(error.getMessage());
            }
        });
    }

    private void requestSessionDetails(final ClassSession session) throws JSONException {
        String url = Http.getInstance(getApplication().getApplicationContext()).getEndPoint() + "/ApplicationManager.xsjs?action=getCurrentBatchDetails";
        JSONObject payload = new JSONObject();
        payload.put("BatchUUID", session.getBatch().getUUID());
        Http.getInstance(getApplication().getApplicationContext()).makeJsonObjectRequest(Request.Method.POST, url, payload, new Response.Listener() {
            @Override
            public void onResponse(Object response) {
                try {
                    JSONObject responseObj = (JSONObject) response;
                    int responseSuccess = responseObj.getInt("statusCode");
                    if (responseSuccess == 200) {
                        JSONObject batchDetailObj = responseObj.getJSONObject("results");
                        JSONArray scholarListObj = batchDetailObj.getJSONArray("scholars");
                        ArrayList<Student> studentList = new ArrayList<>();
                        for (int i = 0; i < scholarListObj.length(); i++) {
                            JSONObject scholarObj = scholarListObj.getJSONObject(i);
                            String uuid = scholarObj.getString("EmpUUID");
                            String empID = scholarObj.getString("EmpNumber");
                            String name = scholarObj.getString("FName") + " " + scholarObj.getString("MName") + " " + scholarObj.getString("Lname");
                            String email = scholarObj.getString("Email");
                            String bitsID = scholarObj.getString("BITSRollNo");
                            String phone = scholarObj.getString("ContactNo");
                            Student student = new Student(uuid, empID, bitsID, name, email, phone);
                            studentList.add(student);
                        }
                        session.getBatch().setStudentList(studentList);
                        requestMaxSessionNumber(session);
                    } else {
                        Banner.showErrorBanner("Error in data received");
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    Banner.showErrorBanner("Error in data received");
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Banner.showErrorBanner(error.getMessage());
            }
        });
    }

    private void requestSessionDetailsCR(final ClassSession session) throws JSONException {
        String username = Persistence.getInstance(getApplication().getApplicationContext()).getLoggedInUsername();
        String url = Http.getInstance(getApplication().getApplicationContext()).getEndPoint() + "/ApplicationManager.xsjs?action=getBatchDetailsCR&email="+username;
        JSONObject payload = new JSONObject();
        payload.put("SubUUID", session.getSubject().getUuid());
        payload.put("SemesterNo", session.getSemester());
        payload.put("Session", session.getSessionNumber());
        payload.put("BatchYear", session.getBatch().getYear());
        payload.put("BatchType", session.getBatch().getType());
        Http.getInstance(getApplication().getApplicationContext()).makeJsonObjectRequest(Request.Method.POST, url, payload, new Response.Listener() {
            @Override
            public void onResponse(Object response) {
                try {
                    JSONObject responseObj = (JSONObject) response;
                    int responseSuccess = responseObj.getInt("statusCode");
                    if (responseSuccess == 200) {
                        JSONArray scholarListObj = responseObj.getJSONArray("results");
                        ArrayList<Student> studentList = new ArrayList<>();
                        for (int i = 0; i < scholarListObj.length(); i++) {
                            JSONObject scholarObj = scholarListObj.getJSONObject(i);
                            String uuid = scholarObj.getString("EmpUUID");
                            String empID = scholarObj.getString("EmpNumber");
                            String name = scholarObj.getString("FName") + " " + scholarObj.getString("MName") + " " + scholarObj.getString("Lname");
                            String email = scholarObj.getString("Email");
                            String bitsID = scholarObj.getString("BITSRollNo");
                            String phone = scholarObj.getString("ContactNo");
                            Student student = new Student(uuid, empID, bitsID, name, email, phone);
                            student.setAbsent(scholarObj.getBoolean("IsAbsent"));
                            studentList.add(student);
                        }
                        Collections.sort(studentList, new StudentComparotar(true));
                        session.getBatch().setStudentList(studentList);
                        requestMaxSessionNumber(session);
                    } else {
                        Banner.showErrorBanner("Error in data received");
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    Banner.showErrorBanner("Error in data received");
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Banner.showErrorBanner(error.getMessage());
            }
        });
    }

    public void requestMaxSessionNumber(final ClassSession session) throws JSONException {
        String username = Persistence.getInstance(getApplication().getApplicationContext()).getLoggedInUsername();
        String url = Http.getInstance(getApplication().getApplicationContext()).getEndPoint() + "/ApplicationManager.xsjs?action=getCurrentSessionByEmail&email="+username;
        JSONObject payload = new JSONObject();
        payload.put("SubUUID", session.getSubject().getUuid());
        payload.put("SemesterNo", session.getSemester());
        payload.put("BatchUUID", session.getBatch().getUUID());
        payload.put("role", "FACULTY");
        Http.getInstance(getApplication().getApplicationContext()).makeJsonObjectRequest(Request.Method.POST, url, payload, new Response.Listener() {
            @Override
            public void onResponse(Object response) {
                try {
                    JSONObject responseObj = (JSONObject) response;
                    int responseSuccess = responseObj.getInt("statusCode");
                    if (responseSuccess == 200) {
                        int maxSessionNumber = responseObj.getInt("sessionNo");
                        session.setMaxSessionNumber(maxSessionNumber);
                        maxSessionNumberHashMap.put(session.getSubject().getUuid(), maxSessionNumber);
                        if (session.getSessionNumber() > maxSessionNumber) {
                            session.setSessionNumber(maxSessionNumber);
                        }
                        requestAbsenteeList(session);
                    } else {
                        Banner.showErrorBanner("Error in data received");
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    Banner.showErrorBanner("Error in data received");
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Banner.showErrorBanner(error.getMessage());
            }
        });
    }

    public void requestAbsenteeList(final ClassSession session) throws JSONException {
        String username = Persistence.getInstance(getApplication().getApplicationContext()).getLoggedInUsername();
        String url = Http.getInstance(getApplication().getApplicationContext()).getEndPoint() + "/ApplicationManager.xsjs?action=getAbsenteesCombinedByEmail&email="+username;
        JSONObject payload = new JSONObject();
        payload.put("SubUUID", session.getSubject().getUuid());
        payload.put("SemesterNo", session.getSemester());
        payload.put("Session", session.getSessionNumber());
        payload.put("BatchYear", session.getBatch().getYear());
        payload.put("BatchType", session.getBatch().getType());
        payload.put("role", "FACULTY");
        Http.getInstance(getApplication().getApplicationContext()).makeJsonObjectRequest(Request.Method.POST, url, payload, new Response.Listener() {
            @Override
            public void onResponse(Object response) {
                try {
                    JSONObject responseObj = (JSONObject) response;
                    int responseSuccess = responseObj.getInt("statusCode");
                    if (responseSuccess == 200) {
                        String markStatus = responseObj.getString("flag");
                        switch (markStatus) {
                            case "UNMARKED":
                                session.setStatus(ClassSession.Status.UNMARKED);
                                break;
                            case "TEMP":
                                session.setStatus(ClassSession.Status.WAITING_FOR_APPROVAL);
                                break;
                            case "FINAL":
                                session.setStatus(ClassSession.Status.APPROVED);
                                break;
                            case "DISC":
                                session.setStatus(ClassSession.Status.DISCREPANCY);
                                break;
                            default:
                                break;
                        }
                        JSONArray scholarInumberObj = responseObj.getJSONArray("results");

                        if (scholarInumberObj.length() != 0) {
                            if (!scholarInumberObj.getString(0).equals("")) {
                                // this is done to prevent absentees from AttendanceCR table
                                resetAttendance(session);
                                for (int i = 0; i < scholarInumberObj.length(); i++) {
                                    String Inumber = scholarInumberObj.getString(i);
                                    for (Student student : session.getBatch().getStudentList()) {

                                        if (student.getID().equals(Inumber)) {
                                            student.setAbsent(true);
                                            break;
                                        }
                                    }
                                }
                            }
                        }
                        session.refreshAbsenteeList();
//                        session.setNew(session.getAbsentStudentList().isEmpty() && !alreadyMarked);
                        updateListenersOnSessionListAvailable(sessionModelList);
                    } else {
                        Banner.showErrorBanner("Error in data received");
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    Banner.showErrorBanner("Error in data received");
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Banner.showErrorBanner(error.getMessage());
            }
        });
    }

    private void postAbsenteeList(final ClassSession session) throws JSONException {
        String username = Persistence.getInstance(getApplication().getApplicationContext()).getLoggedInUsername();
        String url = Http.getInstance(getApplication().getApplicationContext()).getEndPoint() + "/ApplicationManager.xsjs?action=addAbsentees&email="+username;
        JSONObject payload = new JSONObject();
        payload.put("email", this.facultyModel.getEmail());
        payload.put("semNo", session.getSemester());
        payload.put("subUUID", session.getSubject().getUuid());
        payload.put("sessionNo", session.getSessionNumber());
        payload.put("batchYear", session.getBatch().getYear());
        payload.put("batchType", session.getBatch().getType());

        ArrayList<String> absenteeUUIDObj = new ArrayList<>();
        if (session.getAbsentStudentList().size() != 0) {
            for (Student absentee : session.getAbsentStudentList()) {
                absenteeUUIDObj.add(absentee.getUuid());
            }
        } else {
            absenteeUUIDObj.add("A5DD84590F53C563E10000000A78ABEF");
        }
        JSONArray absenteeArrayObj = new JSONArray(absenteeUUIDObj);
        payload.put("absentees", absenteeArrayObj);
        Http.getInstance(getApplication().getApplicationContext()).makeJsonObjectRequest(Request.Method.POST, url, payload, new Response.Listener() {
            @Override
            public void onResponse(Object response) {
                try {
                    JSONObject responseObj = (JSONObject) response;
                    int responseSuccess = responseObj.getInt("statusCode");
                    if (responseSuccess == 200) {
                        resetAttendance(session);
                        updateListenersOnSessionListUpdated(true, null);
                    } else {
                        updateListenersOnSessionListUpdated(false, null);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    Banner.showErrorBanner("Error in data received");
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Banner.showErrorBanner(error.getMessage());
            }
        });
    }

    public void requestSessionModelList(boolean forceReload) {
        if (this.sessionModelList == null || forceReload) {
            requestBatchList();
        } else {
            this.updateListenersOnSessionListAvailable(this.sessionModelList);
        }
    }

    public void requestSessionModelList(int sessionNumber, boolean forceReload) {
        this.currentSessionNumber = sessionNumber;
        this.requestSessionModelList(forceReload);
    }

    public void requestFacultyModelList(boolean forceReload) {
        if (this.facultyModel == null || forceReload) {
            String username = Persistence.getInstance(getApplication().getApplicationContext()).getLoggedInUsername();
            String password = Persistence.getInstance(getApplication().getApplicationContext()).getLoggedInPassword();
            String url = Http.getInstance(getApplication().getApplicationContext()).getEndPoint() + "/GetFacultyDetail.xsjs?email=" + username + "&password=" + password;
            Http.getInstance(getApplication().getApplicationContext()).makeStringRequest(Request.Method.GET, url, new Response.Listener() {
                @Override
                public void onResponse(Object response) {
                    try {
                        JSONObject responseObj = new JSONObject((String) response);
                        int responseSuccess = responseObj.getInt("result");
                        if (responseSuccess == 1) {
                            JSONObject facultyObj = responseObj.getJSONObject("FacultyDetail");
                            String id = facultyObj.has("EmployeeNumber") ? facultyObj.getString("EmployeeNumber") : "";
                            String name = facultyObj.has("Name") ? facultyObj.getString("Name") : "";
                            String email = facultyObj.has("Email") ? facultyObj.getString("Email") : "";
                            String phone = facultyObj.has("ContactNo") ? facultyObj.getString("ContactNo") : "";
                            facultyModel = new Faculty(id, name, email, phone);
                            updateListenersOnFacultyDataAvailable(facultyModel);
                        } else {
                            getApplication().resetData();
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                        Banner.showErrorBanner("Error in data received");
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Banner.showErrorBanner(error.getMessage());
                }
            });
        } else {
            this.updateListenersOnFacultyDataAvailable(this.facultyModel);
        }
    }

    public void updateSession(ClassSession session) {
        try {
            this.postAbsenteeList(session);
        } catch (JSONException e) {
            e.printStackTrace();
            Banner.showErrorBanner("Error in data to be sent");
        }
    }

    private void updateListenersOnSessionListAvailable(List<ClassSession> sessionList) {
        for (OnClassSessionDataListener listener : mClassSessionDataListeners) {
            listener.onClassSessionListAvailable(sessionList);
        }
    }

    private void updateListenersOnSessionListUpdated(boolean status, String error) {
        for (OnClassSessionDataListener listener : mClassSessionDataListeners) {
            listener.onClassSessionListUpdated(status, error);
        }
    }

    private void updateListenersOnFacultyDataAvailable(Faculty faculty) {
        for (OnFacultyDataListener listener : mFacultyDataListeners) {
            listener.onFacultyDataAvailable(faculty);
        }
    }

    public interface OnClassSessionDataListener {
        void onClassSessionListAvailable(List<ClassSession> sessionList);

        void onClassSessionListUpdated(boolean status, String error);
    }

    public interface OnFacultyDataListener {
        void onFacultyDataAvailable(Faculty faculty);
    }

    public void resetAttendance(ClassSession session){
        ArrayList<Student> studentList = new ArrayList<>();
        for(Student student: session.getBatch().getStudentList()){
            student.setAbsent(false);
            studentList.add(student);
        }
        session.getBatch().setStudentList(studentList);
    }
}
