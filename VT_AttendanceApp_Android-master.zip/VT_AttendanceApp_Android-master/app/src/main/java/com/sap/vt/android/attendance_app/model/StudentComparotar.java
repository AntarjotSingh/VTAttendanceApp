package com.sap.vt.android.attendance_app.model;

import java.util.Comparator;

public class StudentComparotar implements Comparator {

    boolean useAttendance;

    public StudentComparotar(){

    }

    public StudentComparotar(boolean useAttendance){
        this.useAttendance = useAttendance;
    }

    @Override
    public int compare(Object object1, Object object2) {
        Student student1 = (Student) object1;
        Student student2 = (Student) object2;
        int attCompare;
        if (useAttendance) {
            attCompare = Boolean.toString(!(student1.isAbsent())).compareTo(Boolean.toString(!(student2.isAbsent())));
        } else {
            attCompare = Boolean.toString((student1.isAbsent())).compareTo(Boolean.toString((student2.isAbsent())));
        }
        int nameCompare = (student1.getName().compareTo(student2.getName()));

        if (attCompare >= 0 && nameCompare >= 0) {
            return nameCompare;
        } else if (attCompare < 0 && nameCompare > 0) {
            return attCompare;
        } else if (attCompare > 0 && nameCompare < 0) {
            return attCompare;
        } else {
            return -1;
        }
    }
}
