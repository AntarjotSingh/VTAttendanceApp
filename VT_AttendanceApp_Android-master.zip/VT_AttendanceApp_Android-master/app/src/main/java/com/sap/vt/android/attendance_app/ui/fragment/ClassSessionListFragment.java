package com.sap.vt.android.attendance_app.ui.fragment;

import android.app.Activity;
import android.app.Fragment;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.sap.vt.R;
import com.sap.vt.android.attendance_app.manager.MarkAttendanceDataManager;
import com.sap.vt.android.attendance_app.model.ClassSession;
import com.sap.vt.android.attendance_app.service.Persistence;
import com.sap.vt.android.attendance_app.ui.activity.BaseActivity;
import com.sap.vt.android.attendance_app.ui.activity.MainActivity;
import com.sap.vt.android.attendance_app.ui.adapter.SessionListAdapter;
import com.sap.vt.android.attendance_app.ui.listener.RecyclerItemTouchListener;

import java.util.List;

/**
 * Created by I328028 on 6/13/2017.
 */

public class ClassSessionListFragment extends Fragment implements RecyclerItemTouchListener.OnItemClickListener, MarkAttendanceDataManager.OnClassSessionDataListener {

    public final static String TAG = "Fragment.BatchList";

    RecyclerView mSessionListRView;
    FragmentListener mListener;
    SessionListAdapter mSessionListAdapter;
    TextView textViewTitle;
    String designation;

    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_session_list, container, false);
        mSessionListRView = (RecyclerView) view.findViewById(R.id.mark_attendance_session_recycler_view);
        textViewTitle = (TextView) view.findViewById(R.id.titleSessionList);
        mSessionListRView.addOnItemTouchListener(new RecyclerItemTouchListener(this.getActivity(), mSessionListRView, this));
        mSessionListAdapter = new SessionListAdapter(null);
        mSessionListRView.setAdapter(mSessionListAdapter);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getActivity());
        mSessionListRView.setLayoutManager(mLayoutManager);
        mSessionListRView.setItemAnimator(new DefaultItemAnimator());

        MarkAttendanceDataManager.getInstance().addSessionModelListener(this);

        return view;
    }

    @Override
    public void onStart() {
        super.onStart();
        designation = Persistence.getInstance(getActivity()).getDesignation();
        if (designation.equals("CR")){
            textViewTitle.setText(R.string.session_list_title_subject);
        }
        ((BaseActivity) getActivity()).showProgressDialog(R.string.loading_data);
        MarkAttendanceDataManager.getInstance().requestSessionModelList(1, false);
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof MainActivity) {
            this.mListener = (FragmentListener) getActivity();
        }
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        if (activity instanceof MainActivity) {
            this.mListener = (FragmentListener) getActivity();
        }
    }

    @Override
    public void onDestroyView() {
        MarkAttendanceDataManager.getInstance().removeSessionModelListener(this);
        ((BaseActivity) getActivity()).dismissDialog();
        super.onDestroyView();
    }

    @Override
    public void onRecyclerItemClick(View view, int position) {
        if (this.mListener != null) {
            this.mListener.onFragmentUpdate(ClassSessionListFragment.TAG, position);
        }
    }

    @Override
    public void onRecyclerItemLongClick(View view, int position) {

    }

    @Override
    public void onClassSessionListAvailable(List<ClassSession> sessionList) {
        this.mSessionListAdapter.setSessionList(sessionList);
        ((BaseActivity) getActivity()).dismissDialog();
    }

    @Override
    public void onClassSessionListUpdated(boolean status, String error) {

    }
}
