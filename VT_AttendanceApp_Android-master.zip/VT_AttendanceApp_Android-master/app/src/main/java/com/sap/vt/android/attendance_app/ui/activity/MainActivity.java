package com.sap.vt.android.attendance_app.ui.activity;

import android.app.Activity;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.widget.TextView;

import com.afollestad.materialdialogs.DialogAction;
import com.afollestad.materialdialogs.MaterialDialog;
import com.sap.vt.R;
import com.sap.vt.android.attendance_app.AttendanceApplication;
import com.sap.vt.android.attendance_app.manager.DataManager;
import com.sap.vt.android.attendance_app.manager.HashGenerator;
import com.sap.vt.android.attendance_app.manager.MarkAttendanceDataManager;
import com.sap.vt.android.attendance_app.model.Faculty;
import com.sap.vt.android.attendance_app.service.Persistence;
import com.sap.vt.android.attendance_app.ui.Banner;
import com.sap.vt.android.attendance_app.ui.fragment.ChangePasswordFragment;
import com.sap.vt.android.attendance_app.ui.fragment.ClassSessionDetailFragment;
import com.sap.vt.android.attendance_app.ui.fragment.ClassSessionListFragment;
import com.sap.vt.android.attendance_app.ui.fragment.FragmentListener;
import com.sap.vt.android.attendance_app.ui.fragment.LoginFragment;
import com.sap.vt.android.attendance_app.ui.fragment.ProfileFragment;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;

import de.hdodenhof.circleimageview.CircleImageView;

public class MainActivity extends BaseActivity implements FragmentListener, NavigationView.OnNavigationItemSelectedListener, MaterialDialog.SingleButtonCallback, DataManager.OnSessionChangeListener, MarkAttendanceDataManager.OnFacultyDataListener, FragmentManager.OnBackStackChangedListener {

    ActionBarDrawerToggle mDrawerToggle;

    NavigationView mNavigationView;
    DrawerLayout mDrawerLayout;
    private String currentFragmentTag;
    private int selectedNavMenuID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initAppBar();
        initNavigationDrawer();

        getFragmentManager().addOnBackStackChangedListener(this);

        mDrawerLayout = (DrawerLayout) findViewById(R.id.main_drawer_layout);

        DataManager.getInstance().addSessionChangeListener(this);
        MarkAttendanceDataManager.getInstance().addFacultyModelListener(this);
        MarkAttendanceDataManager.getInstance().requestFacultyModelList(false);

        if (savedInstanceState == null) {
            this.setFragment(ClassSessionListFragment.TAG, null);
        } else {
            String fragmentTag = savedInstanceState.getString("currentFragment");
            Object parameter = null;
            if (fragmentTag.equals(ClassSessionDetailFragment.TAG)) {
                parameter = savedInstanceState.getInt("currentFragmentParameter");
            }
            this.setFragment(fragmentTag, parameter);
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        outState.putString("currentFragment", this.currentFragmentTag);
        if (this.currentFragmentTag.equals(ClassSessionDetailFragment.TAG) && getFragmentManager().findFragmentByTag(ClassSessionDetailFragment.TAG) != null) {
            outState.putInt("currentFragmentParameter", ((ClassSessionDetailFragment) getFragmentManager().findFragmentByTag(ClassSessionDetailFragment.TAG)).getPositionOfClassSessionItem());
        }
        super.onSaveInstanceState(outState);
    }

    @Override
    public void onFragmentUpdate(String currentFragmentTag, Object parameter) {
        switch (currentFragmentTag) {
            case ClassSessionListFragment.TAG:
                this.setFragment(ClassSessionDetailFragment.TAG, parameter);
                break;
            case ClassSessionDetailFragment.TAG:
                Intent searchIntent = new Intent(this, SearchActivity.class);
                searchIntent.putExtra(SearchActivity.TAG, (int) parameter);
                this.startActivity(searchIntent);
                break;
            case ChangePasswordFragment.TAG:
                if (parameter == null){
                } else {
                    String hashOldPassword = null;
                    try {
                        hashOldPassword = URLDecoder.decode(Persistence.getInstance(getApplicationContext()).getLoggedInPassword(),"UTF-8");
                        String hashNewPassword = HashGenerator.getInstance().generateHash((String) parameter);
                        this.showProgressDialog(R.string.changing_password);
                        DataManager.getInstance().requestChangePassword(Persistence.getInstance(getApplicationContext()).getLoggedInUsername(), hashOldPassword, hashNewPassword);
                    } catch (UnsupportedEncodingException e) {
                        e.printStackTrace();
                    }
                }
        }
    }

    @Override
    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        mDrawerToggle.syncState();
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        mDrawerToggle.onConfigurationChanged(newConfig);
    }

    @Override
    protected void onDestroy() {
        clearReferences();
        super.onDestroy();
        DataManager.getInstance().removeSessionChangeListener(this);
        MarkAttendanceDataManager.getInstance().removeFacultyModelListener(this);
    }

    private void initAppBar() {
        Toolbar toolbar = (Toolbar) findViewById(R.id.main_toolbar);
        setSupportActionBar(toolbar);
        DrawerLayout mDrawerLayout = (DrawerLayout) findViewById(R.id.main_drawer_layout);
        mDrawerToggle = new ActionBarDrawerToggle(this, mDrawerLayout, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        mDrawerToggle.setDrawerIndicatorEnabled(true);
        mDrawerLayout.addDrawerListener(mDrawerToggle);
        mDrawerToggle.syncState();
    }

    private void initNavigationDrawer() {
        mNavigationView = (NavigationView) findViewById(R.id.navigation_drawer);
        mNavigationView.setNavigationItemSelectedListener(this);
    }

    private void setFragment(String fragmentTag, Object fragmentParameter) {
        this.currentFragmentTag = fragmentTag;
        FragmentManager fManager = getFragmentManager();
        FragmentTransaction fTransaction = fManager.beginTransaction();
        fTransaction.setCustomAnimations(R.animator.enter_from_right, R.animator.exit_to_left, R.animator.enter_from_left, R.animator.exit_to_right);
        Fragment fragment = fManager.findFragmentByTag(this.currentFragmentTag);

        if (fragment == null) {
            switch (this.currentFragmentTag) {
                case ClassSessionListFragment.TAG:
                    fragment = new ClassSessionListFragment();
                    break;
                case ClassSessionDetailFragment.TAG:
                    fragment = new ClassSessionDetailFragment();
                    fTransaction.addToBackStack(this.currentFragmentTag);
                    break;
                case ProfileFragment.TAG:
                    fragment = new ProfileFragment();
                    fTransaction.addToBackStack(this.currentFragmentTag);
                    break;
                case ChangePasswordFragment.TAG:
                    fragment = new ChangePasswordFragment();
                    fTransaction.addToBackStack(this.currentFragmentTag);
                    break;
            }

            fTransaction.replace(R.id.main_fragmentContainer, fragment, this.currentFragmentTag);
            fTransaction.commitAllowingStateLoss();
        } else {
            if (!fManager.findFragmentByTag(this.currentFragmentTag).isVisible()) {
                fManager.popBackStack();
            }
        }

        //Set Parameters here
        switch (this.currentFragmentTag) {
            case ClassSessionListFragment.TAG:
                break;
            case ClassSessionDetailFragment.TAG:
                ((ClassSessionDetailFragment) fragment).setPositionOfClassSessionItem((int) fragmentParameter);
                break;
            case ProfileFragment.TAG:
                break;
        }
        this.refreshActionBarAndNavigationView();
    }

    private void refreshActionBarAndNavigationView() {
        switch (this.currentFragmentTag) {
            case ClassSessionListFragment.TAG:
                selectedNavMenuID = R.id.navMarkAttendance;
                getSupportActionBar().setTitle(getResources().getString(R.string.mark_attendance));
                break;
            case ClassSessionDetailFragment.TAG:
                selectedNavMenuID = R.id.navMarkAttendance;
                getSupportActionBar().setTitle(getResources().getString(R.string.mark_attendance));
                break;
            case ProfileFragment.TAG:
                selectedNavMenuID = R.id.navProfile;
                getSupportActionBar().setTitle(getResources().getString(R.string.profile));
                break;
            case ChangePasswordFragment.TAG:
                selectedNavMenuID = R.id.navProfile;
                getSupportActionBar().setTitle(getResources().getString(R.string.changePassword));
                break;
        }
        mNavigationView.setCheckedItem(selectedNavMenuID);
    }

    private void showLogoutDialog() {
        this.showDialog(R.string.logout_confirm, R.string.yes, R.string.no, this);
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.navMarkAttendance:
                this.setFragment(ClassSessionListFragment.TAG, null);
                break;
            case R.id.navProfile:
                this.setFragment(ProfileFragment.TAG, null);
                break;
            case R.id.changePassword:
                this.setFragment(ChangePasswordFragment.TAG, null);
                break;
            case R.id.contactSupport:
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("message/rfc822");
                i.putExtra(Intent.EXTRA_EMAIL  , new String[]{Persistence.getInstance(getBaseContext()).getPrefSupportEmail()});
                i.putExtra(Intent.EXTRA_SUBJECT,  getResources().getString(R.string.support_email_subject));
                i.putExtra(Intent.EXTRA_TEXT   ,  getResources().getString(R.string.support_email_body));
                try {
                    startActivity(Intent.createChooser(i,  getResources().getString(R.string.send_email)));
                } catch (android.content.ActivityNotFoundException ex) {
                    Banner.showErrorBanner(getResources().getString(R.string.email_client_not_found));
                }
                break;
            case R.id.navLogout:
                this.showLogoutDialog();
                break;
        }
        mDrawerLayout.closeDrawers();
        return true;
    }

    @Override
    public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
        if (which == DialogAction.POSITIVE) {
            DataManager.getInstance().requestUserLogout();
            this.dismissDialog();
            this.showProgressDialog(R.string.logging_out);
        } else if (which == DialogAction.NEGATIVE) {
            this.dismissDialog();
            mNavigationView.setCheckedItem(selectedNavMenuID);
        }
    }

    @Override
    public void onLogin(boolean isSuccess, String message) {
        if(isSuccess){
            if (getFragmentManager().findFragmentByTag(ChangePasswordFragment.TAG) != null) {
                ((ChangePasswordFragment) getFragmentManager().findFragmentByTag(ChangePasswordFragment.TAG)).setError(false);
            }
            this.setFragment(ClassSessionListFragment.TAG, null);
        }
    }

    @Override
    public void onLogout() {
        this.dismissDialog();
        ((AttendanceApplication) this.getApplication()).resetData();
    }

    @Override
    public void onFacultyDataAvailable(Faculty faculty) {
        CircleImageView facultyProfilePic = (CircleImageView) mNavigationView.getHeaderView(0).findViewById(R.id.navigation_profile_pic);
        TextView facultyNameTextView = (TextView) mNavigationView.getHeaderView(0).findViewById(R.id.navigation_name);
        TextView facultyEmailTextView = (TextView) mNavigationView.getHeaderView(0).findViewById(R.id.navigation_email);
        if (faculty.getProfilePic() != null) {
            facultyProfilePic.setImageDrawable(faculty.getProfilePic());
        }
        facultyNameTextView.setText(faculty.getName());
        facultyEmailTextView.setText(faculty.getEmail());
    }

    @Override
    public void onBackStackChanged() {
        if (getFragmentManager().findFragmentByTag(ProfileFragment.TAG) != null) {
            if (getFragmentManager().findFragmentByTag(ProfileFragment.TAG).isVisible())
                this.currentFragmentTag = ProfileFragment.TAG;
        }
        if (getFragmentManager().findFragmentByTag(ClassSessionListFragment.TAG) != null) {
            if (getFragmentManager().findFragmentByTag(ClassSessionListFragment.TAG).isVisible())
                this.currentFragmentTag = ClassSessionListFragment.TAG;
        }
        if (getFragmentManager().findFragmentByTag(ClassSessionDetailFragment.TAG) != null) {
            if (getFragmentManager().findFragmentByTag(ClassSessionDetailFragment.TAG).isVisible())
                this.currentFragmentTag = ClassSessionDetailFragment.TAG;
        }
        this.refreshActionBarAndNavigationView();
    }
}
