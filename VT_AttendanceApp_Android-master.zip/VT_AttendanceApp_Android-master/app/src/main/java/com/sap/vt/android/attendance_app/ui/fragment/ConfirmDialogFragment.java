package com.sap.vt.android.attendance_app.ui.fragment;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Bundle;
import android.app.DialogFragment;
import android.support.v7.widget.CardView;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.sap.vt.R;
import com.sap.vt.android.attendance_app.model.Student;
import com.sap.vt.android.attendance_app.ui.activity.BaseActivity;
import com.sap.vt.android.attendance_app.ui.adapter.ConfirmDialogStudentListAdapter;
import com.sap.vt.android.attendance_app.ui.adapter.StudentListAdapter;

import java.util.ArrayList;

/**
 * Created by I353729 on 06/05/2019.
 */

@SuppressLint("ValidFragment")
public class ConfirmDialogFragment extends DialogFragment {
    ConfirmDialogStudentListAdapter mStudentListAdapter;
    private boolean isAbsenteeModeOn;
    private ArrayList<Student> students;
    private ClassSessionDetailFragment ctx ;

    @SuppressLint("ValidFragment")
    public ConfirmDialogFragment (ArrayList<Student> students, boolean isAbsenteeModeOn, ClassSessionDetailFragment ctx) {
        this.students = students;
        this.isAbsenteeModeOn = isAbsenteeModeOn;
        this.ctx = ctx;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.confirm_dialog, null);
        RecyclerView studentListRecyclerView = (RecyclerView) view.findViewById(R.id.session_student_list_recycle_view);
        studentListRecyclerView.requestDisallowInterceptTouchEvent(true);
        TextView confirmDialogTitle = (TextView) view.findViewById(R.id.confirmDialogTitle);
        Button submit = (Button) view.findViewById(R.id.confirmDialogYes);
        Button cancel = (Button) view.findViewById(R.id.confirmDialogNo);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(this.getActivity());
        studentListRecyclerView.setLayoutManager(mLayoutManager);
        studentListRecyclerView.setItemAnimator(new DefaultItemAnimator());
        mStudentListAdapter = new ConfirmDialogStudentListAdapter(null);
        ArrayList<Student> checkdStudent = new ArrayList<Student>();
        mStudentListAdapter.setMarkAbsenteeMode(isAbsenteeModeOn);

        if (isAbsenteeModeOn){
            confirmDialogTitle.setText(R.string.list_of_absentees);
        } else {
            confirmDialogTitle.setText(R.string.list_of_presentees);
        }

        for (Student student: this.students) {
            if(isAbsenteeModeOn) {
                if (student.isAbsent()) {
                    checkdStudent.add(student);
                }
            } else {
                if (!student.isAbsent()) {
                    checkdStudent.add(student);
                }
            }
        }
        mStudentListAdapter.setStudentList(checkdStudent);
        studentListRecyclerView.setAdapter(mStudentListAdapter);
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(ctx.isNoAbsenteeSelected){
                    ctx.isNoAbsenteeSelected = false;
                    if (ctx.classSessionModel.isModifiable()) {
                        ((BaseActivity) ctx.getActivity()).showDialog(R.string.submit_attendance_confirm, R.string.yes, R.string.no, ctx);
                    } else {
                        ((BaseActivity) ctx.getActivity()).showDialog(R.string.submit_attendance_confirm, R.string.submit_attendance_confirm_caution, R.string.yes, R.string.no, ctx);
                    }
                }
                dismiss();
                ((BaseActivity) ctx.getActivity()).dismissDialog();
                ctx.submitSessionModelList();
            }
        });

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(ctx.isNoAbsenteeSelected) {
                    ctx.isNoAbsenteeSelected = false;
                }
                dismiss();
            }
        });
        return view;
    }
}
