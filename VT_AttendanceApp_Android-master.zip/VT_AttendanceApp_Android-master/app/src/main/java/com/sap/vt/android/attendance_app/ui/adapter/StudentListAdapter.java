package com.sap.vt.android.attendance_app.ui.adapter;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.design.widget.CoordinatorLayout;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.ToggleButton;

import com.androidadvance.topsnackbar.TSnackbar;
import com.github.aakira.expandablelayout.ExpandableLinearLayout;
import com.sap.vt.R;
import com.sap.vt.android.attendance_app.model.Student;
import com.sap.vt.android.attendance_app.ui.Banner;
import com.sap.vt.android.attendance_app.ui.fragment.ClassSessionDetailFragment;

import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

/**
 * Created by I327891 on 12-Jul-17.
 */

public class StudentListAdapter extends RecyclerView.Adapter {

    List<Student> studentList;
    private boolean isInMarkAbsenteeMode = true;
    public ClassSessionDetailFragment classSessionDetailFragment;
    private View globalView;

    public StudentListAdapter(List<Student> studentList) {
        this.studentList = studentList;
    }

    public void setView(@NonNull View globalView) {
        this.globalView = globalView;
    }


    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.layout_listitem_student, parent, false);
        return new StudentListAdapter.StudentItemViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        final Student student = this.studentList.get(position);

        holder.setIsRecyclable(false);
        ((StudentItemViewHolder) holder).expandableLinearLayout.setInRecyclerView(true);
        if(!isInMarkAbsenteeMode) {
            ((StudentItemViewHolder) holder).absentCheckbox.setChecked(!student.isAbsent());
        } else {
            ((StudentItemViewHolder) holder).absentCheckbox.setChecked(student.isAbsent());
        }
        ((StudentItemViewHolder) holder).nameTextView.setText(student.getName());
        ((StudentItemViewHolder) holder).BitsIDTextView.setText(student.getBITS_ID());
        ((StudentItemViewHolder) holder).INumberTextView.setText(student.getID());
        ((StudentItemViewHolder) holder).emailTextView.setText(student.getEmail());
        ((StudentItemViewHolder) holder).phoneTextView.setText(student.getPhoneNumber());
        if (student.getProfilePic() == null) {
            ((StudentItemViewHolder) holder).profilePicImageView.setImageResource(R.drawable.ic_face_grey_600_48dp);
        } else {
            ((StudentItemViewHolder) holder).profilePicImageView.setImageDrawable(student.getProfilePic());
        }
        ((StudentItemViewHolder) holder).setListener(new OnAbsenteeStateChangeListener() {
            @Override
            public void onAbsenteeCheckedChange(boolean state) {
                student.setAbsent(state);
            }
        });

        ((StudentItemViewHolder) holder).expandableLinearLayout.collapse();
        ((StudentItemViewHolder) holder).expandableLinearLayout.initLayout(); //Needed to recalculate the layout
        ((StudentItemViewHolder) holder).expandToggleButton.setChecked(false);
    }

    @Override
    public int getItemCount() {
        return this.studentList == null ? 0 : this.studentList.size();
    }

    public List<Student> getStudentList() {
        return this.studentList;
    }

    public void setStudentList(List<Student> studentList) {
        this.studentList = studentList;
        this.notifyDataSetChanged();
    }

    public void setMarkAbsenteeMode(boolean markAbsenteeMode) {
        this.isInMarkAbsenteeMode = markAbsenteeMode;
    }

    public boolean isInMarkAbsenteeMode() {
        return this.isInMarkAbsenteeMode;
    }

    interface OnAbsenteeStateChangeListener {
        void onAbsenteeCheckedChange(boolean state);
    }

    public class StudentItemViewHolder extends RecyclerView.ViewHolder implements ToggleButton.OnCheckedChangeListener, View.OnClickListener {
        TextView nameTextView, BitsIDTextView, INumberTextView, emailTextView, phoneTextView;
        CheckBox absentCheckbox;
        ToggleButton expandToggleButton;
        CircleImageView profilePicImageView;
        ExpandableLinearLayout expandableLinearLayout;
        LinearLayout emailLinearLayout, phoneLinearLayout, studentDetailLayout;

        OnAbsenteeStateChangeListener mListener;

        Context context;

        public StudentItemViewHolder(View itemView) {
            super(itemView);

            context = itemView.getContext();
            nameTextView = (TextView) itemView.findViewById(R.id.student_list_item_name);
            BitsIDTextView = (TextView) itemView.findViewById(R.id.student_list_item_bits_id);
            INumberTextView = (TextView) itemView.findViewById(R.id.student_list_item_i_number);
            emailTextView = (TextView) itemView.findViewById(R.id.student_list_item_email);
            phoneTextView = (TextView) itemView.findViewById(R.id.student_list_item_phone);
            absentCheckbox = (CheckBox) itemView.findViewById(R.id.student_list_item_check_box);
            expandToggleButton = (ToggleButton) itemView.findViewById(R.id.student_list_item_expand_button);
            profilePicImageView = (CircleImageView) itemView.findViewById(R.id.student_list_item_profile_pic);
            expandableLinearLayout = (ExpandableLinearLayout) itemView.findViewById(R.id.student_list_item_expandableLayout);
            emailLinearLayout = (LinearLayout) itemView.findViewById(R.id.student_extra_listitem_email);
            phoneLinearLayout = (LinearLayout) itemView.findViewById(R.id.student_extra_listitem_phone);
            studentDetailLayout = (LinearLayout) itemView.findViewById(R.id.studentDetailLayout);

            emailLinearLayout.setOnClickListener(this);
            phoneLinearLayout.setOnClickListener(this);

            expandToggleButton.setOnCheckedChangeListener(this);
            absentCheckbox.setOnCheckedChangeListener(this);
            studentDetailLayout.setOnClickListener(this);
        }

        @Override
        public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
            if (buttonView == expandToggleButton) {
                if (isChecked) {
                    expandableLinearLayout.expand();
                } else {
                    expandableLinearLayout.collapse();
                }
            } else if (buttonView == absentCheckbox) {
                if (this.mListener != null) {
                    if (isInMarkAbsenteeMode) {
                        this.mListener.onAbsenteeCheckedChange(isChecked);
                    } else {
                        this.mListener.onAbsenteeCheckedChange(!isChecked);
                    }
                    if (classSessionDetailFragment != null) {
                        classSessionDetailFragment.changeCountInTitle();
                        if (isChecked) {
                            showBanner();
                        }
                    }
                }
            }
        }

        @Override
        public void onClick(View v) {
            Intent intent = new Intent();
            if (v == emailLinearLayout) {
                intent.setAction(Intent.ACTION_SEND);
                intent.setType("plain/text");
                intent.putExtra(android.content.Intent.EXTRA_EMAIL, new String[]{emailTextView.getText().toString()});
                context.startActivity(intent);
            } else if (v == phoneLinearLayout) {
                intent.setAction(Intent.ACTION_DIAL);
                intent.setData(Uri.parse("tel:" + phoneTextView.getText().toString()));
                context.startActivity(intent);
            } else if(v == studentDetailLayout){ // clicking on user details to mark attendance
                if (this.mListener != null) {
                    absentCheckbox.setChecked(!absentCheckbox.isChecked());
                    if (isInMarkAbsenteeMode) {
                        this.mListener.onAbsenteeCheckedChange(absentCheckbox.isChecked());
                    } else {
                        this.mListener.onAbsenteeCheckedChange(!absentCheckbox.isChecked());
                    }
                    if (classSessionDetailFragment != null) {
                        classSessionDetailFragment.changeCountInTitle();
                        if (absentCheckbox.isChecked()) {
                            showBanner();
                        }
                    }
                }
            }
        }

        public void setListener(OnAbsenteeStateChangeListener listener) {
            this.mListener = listener;
        }
    }

    public void showBanner() {
        if(globalView != null && classSessionDetailFragment != null) {
            if(Build.VERSION.SDK_INT > 23) {
                Banner.showBanner(classSessionDetailFragment.getResources().getString(R.string.moved_to_top));
            }
        }
    }
}
