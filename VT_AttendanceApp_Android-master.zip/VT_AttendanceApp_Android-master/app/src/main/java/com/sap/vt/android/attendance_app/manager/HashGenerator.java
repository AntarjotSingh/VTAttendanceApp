package com.sap.vt.android.attendance_app.manager;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Base64;
import android.util.Log;

import com.sap.vt.android.attendance_app.service.Persistence;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

public class HashGenerator {

        public static HashGenerator instance = null;
        private String secret = Persistence.getInstance(DataManager.getInstance().getApplication().getApplicationContext()).getPrefHmacKey();

        public static HashGenerator getInstance(){
            if (instance == null ) {
                instance = new HashGenerator();
            }
            return instance;
        }

        public String generateHash(String preHashValue) {
            String securePassword = get_SHA_512_SecurePassword(preHashValue);
            return securePassword.replaceAll("\\s+","");
        }

        private String get_SHA_512_SecurePassword(String preHashValue)
        {
            try {
                Mac sha_HMAC = Mac.getInstance("HmacSHA512");

                SecretKeySpec secret_key = new SecretKeySpec(secret.getBytes(), "HmacSHA512");
                sha_HMAC.init(secret_key);

                String hash = Base64.encodeToString(sha_HMAC.doFinal(preHashValue.getBytes()), Base64.DEFAULT);
                return hash;
            }
            catch (Exception e){
                System.out.println("Error");
            }
            return null;
        }
    }
