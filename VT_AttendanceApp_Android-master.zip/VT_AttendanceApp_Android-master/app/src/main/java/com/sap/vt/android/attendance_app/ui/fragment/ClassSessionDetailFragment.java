package com.sap.vt.android.attendance_app.ui.fragment;

import android.app.Activity;
import android.app.Fragment;
import android.app.FragmentManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.view.MenuItemCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.AppCompatButton;
import android.support.v7.widget.CardView;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SearchView;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;

import com.afollestad.materialdialogs.DialogAction;
import com.afollestad.materialdialogs.MaterialDialog;
import com.sap.vt.R;
import com.sap.vt.android.attendance_app.database.DatabaseHelper;
import com.sap.vt.android.attendance_app.manager.DataManager;
import com.sap.vt.android.attendance_app.manager.MarkAttendanceDataManager;
import com.sap.vt.android.attendance_app.model.ClassSession;
import com.sap.vt.android.attendance_app.model.Student;
import com.sap.vt.android.attendance_app.model.StudentComparotar;
import com.sap.vt.android.attendance_app.service.Persistence;
import com.sap.vt.android.attendance_app.ui.Banner;
import com.sap.vt.android.attendance_app.ui.activity.BaseActivity;
import com.sap.vt.android.attendance_app.ui.activity.MainActivity;
import com.sap.vt.android.attendance_app.ui.adapter.AbsentStudentListAdapter;
import com.sap.vt.android.attendance_app.ui.adapter.StudentListAdapter;
import com.sap.vt.android.attendance_app.util.Constants;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.List;

/**
 * Created by I327891 on 10-Jul-17.
 */

public class ClassSessionDetailFragment extends Fragment implements MarkAttendanceDataManager.OnClassSessionDataListener,
        View.OnClickListener, SearchView.OnQueryTextListener,
        MaterialDialog.SingleButtonCallback,
        MaterialDialog.ListCallback,
        CompoundButton.OnCheckedChangeListener {

    public final static String TAG = "Fragment.BatchAttendanceDetail";
    FloatingActionButton fab, copy_attendance_prev_session, fabUp;
    ClassSession classSessionModel;
    boolean isNoAbsenteeSelected = false;
    private int _sessionItemPosition;
    private ConfirmDialogFragment confirmDialogFragment;
    private FragmentListener mListener;
    private LinearLayout mStudentListSwitchLayout;
    private TextView mSubjectTextView, mSemesterTextView, mSessionNoTextView, mSessionApprovalStatusTextView;
    private RecyclerView studentListRecyclerView;
    private TextView mStudentListCardTitleTextView;
    private AppCompatButton mButton;
    private CardView sessionOverviewCardView;
    private Switch mStudentListMarkSwitch;
    private DatabaseHelper databaseHelper, databaseHelperLatest;
    private AbsentStudentListAdapter mAbsentStudentListAdapter;
    private StudentListAdapter mStudentListAdapter;
    private boolean isMarkMode;
    private ScrollView scrollView;
    private ImageView shareButton;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_session_attendance_detail, container, false);

        copy_attendance_prev_session = view.findViewById(R.id.mark_from_previos_session);
        copy_attendance_prev_session.setOnClickListener(this);

        fab = view.findViewById(R.id.batch_attendance_detail_fab);
        fab.setOnClickListener(this);
        fabUp = view.findViewById(R.id.upFAB);
        fabUp.setOnClickListener(this);
        sessionOverviewCardView = view.findViewById(R.id.session_summary_card);
        mStudentListCardTitleTextView = view.findViewById(R.id.session_student_list_title);
        studentListRecyclerView = view.findViewById(R.id.session_student_list_recycle_view);

        // for smooth working of scrollView
        studentListRecyclerView.setNestedScrollingEnabled(false);
        mStudentListSwitchLayout = view.findViewById(R.id.session_student_list_mark_absentee_layout);
        mAbsentStudentListAdapter = new AbsentStudentListAdapter(null);
        mStudentListAdapter = new StudentListAdapter(null);
        mStudentListAdapter.setView(view);
        mStudentListAdapter.classSessionDetailFragment = this;
        final RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(this.getActivity());
        studentListRecyclerView.setLayoutManager(mLayoutManager);
        studentListRecyclerView.setItemAnimator(new DefaultItemAnimator());

        scrollView = view.findViewById(R.id.batch_attendance_detail_scroll);
        mSubjectTextView = view.findViewById(R.id.session_summary_card_subject_name);
        mSemesterTextView = view.findViewById(R.id.session_summary_card_semester);
        mSessionNoTextView = view.findViewById(R.id.session_summary_card_number);
        mSessionApprovalStatusTextView = view.findViewById(R.id.session_summary_card_approved);
        mStudentListMarkSwitch = view.findViewById(R.id.session_student_list_mark_absentee_switch);
        mButton = view.findViewById(R.id.session_summary_card_button);
        mButton.setOnClickListener(this);
        mStudentListMarkSwitch.setOnCheckedChangeListener(this);

        this.isMarkMode = false;

        MarkAttendanceDataManager.getInstance().addSessionModelListener(this);

        if (Build.VERSION.SDK_INT > 22) {
            scrollView.setOnScrollChangeListener(new View.OnScrollChangeListener() {
                @Override
                public void onScrollChange(View v, int scrollX, int scrollY, int oldScrollX, int oldScrollY) {
                    if (scrollY > 0 && fabUp.getVisibility() != View.VISIBLE) {
                        fabUp.show();
                    } else if (scrollY <= 0 && fabUp.getVisibility() == View.VISIBLE) {
                        fabUp.hide();
                    }
                }
            });
        }

        shareButton = view.findViewById(R.id.share);
        shareButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String header = getString(R.string.subject_share,
                        classSessionModel.getSubject().getName(),
                        classSessionModel.getSessionNumber());

                List<Student> studentList = mStudentListAdapter.getStudentList();
                StringBuilder fullString = new StringBuilder();
                fullString.append(header).append("\n\n");
                for (int i = 0; i < studentList.size(); i++) {
                    if (studentList.get(i).isAbsent()) {
                        fullString.append(studentList.get(i).getName()).append("\n");
                    }
                }
                fullString.append("\n")
                        .append(getString(R.string.share_text_suffix,
                                classSessionModel.getBatch().getName(),
                                classSessionModel.getSemester(),
                                mSessionApprovalStatusTextView.getText()));
                shareOnSupportedApps(fullString.toString());
            }
        });

        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        MarkAttendanceDataManager.getInstance().requestSessionModelList(false);
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof MainActivity) {
            this.mListener = (FragmentListener) getActivity();
        }
        this.requestSessionModelList(false);
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        if (activity instanceof MainActivity) {
            this.mListener = (FragmentListener) getActivity();
        }
        this.requestSessionModelList(false);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        MarkAttendanceDataManager.getInstance().removeSessionModelListener(this);
        ((BaseActivity) getActivity()).dismissDialog();
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.search, menu);
        SearchView searchView = (SearchView) MenuItemCompat.getActionView(menu.findItem(R.id.search));
        searchView.setOnQueryTextListener(this);
        searchView.setOnSearchClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showSessionOverviewCardView(false);
            }
        });
        searchView.setOnCloseListener(new SearchView.OnCloseListener() {
            @Override
            public boolean onClose() {
                showSessionOverviewCardView(true);
                return false;
            }
        });
    }

    void notifyDataChanged() {
        this.mSubjectTextView.setText(this.classSessionModel.getSubject().getName());
        this.mSemesterTextView.setText(String.valueOf(this.classSessionModel.getSemester()));
        this.mSessionNoTextView.setText(String.valueOf(this.classSessionModel.getSessionNumber()));
    }

    private void requestSessionModelList(boolean forceReload) {
        ((BaseActivity) getActivity()).showProgressDialog(R.string.loading_data);
        MarkAttendanceDataManager.getInstance().requestSessionModelList(forceReload);
    }

    private void requestSessionModelList(int sessionNumber, boolean forceReload) {
        ((BaseActivity) getActivity()).showProgressDialog(R.string.loading_data);
        MarkAttendanceDataManager.getInstance().requestSessionModelList(sessionNumber, forceReload);
    }

    public void submitSessionModelList() {
        ((BaseActivity) getActivity()).showProgressDialog(R.string.submitting_data);
        this.classSessionModel.updateStudentList(this.mStudentListAdapter.getStudentList());

        // storing attendance in the database
        databaseHelper.updateAttendanceData((ArrayList<Student>) (this.mStudentListAdapter.getStudentList()));
        databaseHelperLatest.updateAttendanceData((ArrayList<Student>) (this.mStudentListAdapter.getStudentList()));
        MarkAttendanceDataManager.getInstance().updateSession(this.classSessionModel);
    }

    private void searchString(String query) {
        ArrayList<Student> filteredStudents = new ArrayList<>();
        ArrayList<Student> students = (ArrayList) (isMarkMode ? this.classSessionModel.getBatch().getStudentList() : this.classSessionModel.getAbsentStudentList());
        if (!query.equals("")) {
            for (Student student : students) {
                if (student.getName().toLowerCase().contains(query.toLowerCase())) {
                    filteredStudents.add(student);
                }
            }
        } else {
            filteredStudents = students;
        }
        if (isMarkMode) {
            this.mStudentListAdapter.setStudentList(filteredStudents);
        } else {
            this.mAbsentStudentListAdapter.setStudentList(filteredStudents);
        }
    }

    private void showSessionOverviewCardView(boolean isVisible) {
        sessionOverviewCardView.setVisibility(isVisible ? View.VISIBLE : View.GONE);
    }

    private void setMarkMode() {

        // In case CR's attendance is not available for current session
        if (this.classSessionModel.getBatch().getStudentList().isEmpty() && this.isMarkMode) {
            studentListRecyclerView.setVisibility(View.GONE);
            this.copy_attendance_prev_session.hide();
            this.fab.hide();
            this.shareButton.setVisibility(View.GONE);
            this.mStudentListSwitchLayout.setVisibility(View.GONE);
            this.mSessionApprovalStatusTextView.setText(R.string.attendance_not_marked_by_CR);
            return;
        } else {
            studentListRecyclerView.setVisibility(View.VISIBLE);
        }

        this.mStudentListAdapter.setStudentList(this.classSessionModel.getBatch().getStudentList());
        this.mAbsentStudentListAdapter.setStudentList(this.classSessionModel.getAbsentStudentList());
        if (this.classSessionModel.isNew()) {
            this.mSessionApprovalStatusTextView.setVisibility(View.GONE);
        } else {
            this.mSessionApprovalStatusTextView.setVisibility(View.VISIBLE);
            switch (this.classSessionModel.getStatus()) {
                case APPROVED:
                    this.mSessionApprovalStatusTextView.setText(getResources().getString(R.string.approval_done));
                    break;
                case DISCREPANCY:
                    this.mSessionApprovalStatusTextView.setText(getResources().getString(R.string.approval_discrepancy));
                    break;
                case WAITING_FOR_APPROVAL:
                    this.mSessionApprovalStatusTextView.setText(getResources().getString(R.string.approval_waiting));
                    break;
            }
        }
        if (this.isMarkMode) {
            this.mStudentListCardTitleTextView.setText(R.string.list_of_students);
            this.studentListRecyclerView.setAdapter(this.mStudentListAdapter);
            this.changeCountInTitle();
            this.fab.setImageResource(R.drawable.ic_file_upload_white_48dp);
            this.fab.show();
            this.shareButton.setVisibility(View.GONE);
            this.mStudentListSwitchLayout.setVisibility(View.VISIBLE);
            if (databaseHelper.checkIfTableExists() || databaseHelperLatest.checkIfTableExists()) {
                copy_attendance_prev_session.show();
            }

            this.mStudentListSwitchLayout.setVisibility(View.VISIBLE);
            this.mStudentListMarkSwitch.setChecked(!this.mStudentListAdapter.isInMarkAbsenteeMode());
        } else {
            this.mStudentListCardTitleTextView.setText(R.string.list_of_absentees);
            this.studentListRecyclerView.setAdapter(this.mAbsentStudentListAdapter);
            this.mStudentListSwitchLayout.setVisibility(View.GONE);
            if (this.classSessionModel.getAbsentStudentList().size() != 0)
                this.shareButton.setVisibility(View.VISIBLE);
            if (this.classSessionModel.isModifiable()) {
                this.fab.setImageResource(R.drawable.ic_edit_white_48dp);
                this.shareButton.setVisibility(View.GONE);
            } else {
                this.copy_attendance_prev_session.hide();
                this.fab.hide();
            }
        }
    }

    public int getPositionOfClassSessionItem() {
        return this._sessionItemPosition;
    }

    public void setPositionOfClassSessionItem(int position) {
        this._sessionItemPosition = position;
    }

    @Override
    public void onClassSessionListAvailable(List<ClassSession> sessionList) {
        this.classSessionModel = sessionList.get(this._sessionItemPosition);

        Date c = Calendar.getInstance().getTime();

        SimpleDateFormat df = new SimpleDateFormat("dd_MMM_yyyy");
        String formattedDate = df.format(c);

        // for initiating the database
        databaseHelper = new DatabaseHelper(this.getActivity().getApplicationContext(), (this.replaceSpecialCh(classSessionModel.getSubject().getName() + "_" + classSessionModel.getBatch().getName()).replace(" ", "_") + "_" + Persistence.getInstance(getActivity()).getDesignation() + "_" + formattedDate));
        databaseHelperLatest = new DatabaseHelper(this.getActivity().getApplicationContext(), "Latest_Marked_Attendance" + "__" + (this.replaceSpecialCh(classSessionModel.getBatch().getName()).replace(" ", "_") + "_" + classSessionModel.getSemester() + "_" + Persistence.getInstance(getActivity()).getDesignation() + "_" + formattedDate));
        if (!databaseHelper.checkIfTableExists() && !databaseHelperLatest.checkIfTableExists()) {
            copy_attendance_prev_session.hide();
        }
        this.isMarkMode = this.classSessionModel.isNew();
        this.setMarkMode();
        this.notifyDataChanged();
        ((BaseActivity) getActivity()).dismissDialog();
    }

    @Override
    public void onClassSessionListUpdated(boolean status, String error) {
        if (status) {
            Banner.showSuccessBanner(getResources().getString(R.string.attendance_uploaded));
            mStudentListMarkSwitch.setChecked(false);
        } else {
            String errorMsg = error == null ? getResources().getString(R.string.error_uploading_attendance) : error;
            if (this.getActivity() != null) {
                ((BaseActivity) this.getActivity()).showMessageDialog(R.string.error_uploading_attendance, R.string.error_uploading_attendance_content, R.string.ok, null);
            } else {
                Banner.showErrorBanner(errorMsg);
            }
        }
        this.requestSessionModelList(true);
    }

    @Override
    public void onClick(View v) {
        if (v == fab) {
            if (this.isMarkMode) {
                FragmentManager fm = this.getFragmentManager();
                confirmDialogFragment = new ConfirmDialogFragment((ArrayList<Student>) this.mStudentListAdapter.getStudentList(), mStudentListAdapter.isInMarkAbsenteeMode(), ClassSessionDetailFragment.this);
                confirmDialogFragment.show(fm, "dialogFragment");
            } else {
                this.isMarkMode = true;
                this.setMarkMode();
            }
        } else if (v == copy_attendance_prev_session) {
            AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
            builder.setNegativeButton("Cancel", null);
            builder.setTitle("Copy attendance from a session");

            if (databaseHelper.checkIfTableExists() && databaseHelperLatest.checkIfTableExists()) {
                String[] sessions = {"Previous Session", "Latest Session"};
                builder.setItems(sessions, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        switch (which) {
                            case 0:
                                Banner.showSuccessBanner(getResources().getString(R.string.marking_attendance_from_prev_session));
                                ArrayList<Student> studentArrayList = databaseHelper.getAttendanceData();
                                mStudentListAdapter.setStudentList(studentArrayList);
                                changeCountInTitle();
                                break;
                            case 1:
                                Banner.showSuccessBanner(getResources().getString(R.string.marking_attendance_from_latest_session));
                                studentArrayList = databaseHelperLatest.getAttendanceData();
                                mStudentListAdapter.setStudentList(studentArrayList);
                                changeCountInTitle();
                                break;
                        }
                    }
                });
            } else if (databaseHelper.checkIfTableExists()) {
                String[] sessions = {"Previous Session"};
                builder.setItems(sessions, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        switch (which) {
                            case 0:
                                Banner.showSuccessBanner(getResources().getString(R.string.marking_attendance_from_prev_session));
                                ArrayList<Student> studentArrayList = databaseHelper.getAttendanceData();
                                mStudentListAdapter.setStudentList(studentArrayList);
                                changeCountInTitle();
                                break;
                        }
                    }
                });
            } else if (databaseHelperLatest.checkIfTableExists()) {
                String[] sessions = {"Latest Session"};
                builder.setItems(sessions, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        switch (which) {
                            case 0:
                                Banner.showSuccessBanner(getResources().getString(R.string.marking_attendance_from_latest_session));
                                ArrayList<Student> studentArrayList = databaseHelperLatest.getAttendanceData();
                                mStudentListAdapter.setStudentList(studentArrayList);
                                changeCountInTitle();
                                break;
                        }
                    }
                });
            }


            AlertDialog dialog = builder.create();
            dialog.show();
        } else if (v == mButton) {
            ((BaseActivity) getActivity()).showListDialog(R.string.select_session, MarkAttendanceDataManager.getInstance().getListOfSessionNumbers(classSessionModel), this);
        } else if (v == fabUp) {
            scrollView.fullScroll(View.FOCUS_UP);
            scrollView.fullScroll(View.FOCUS_UP);
            fabUp.hide();
        }
    }

    @Override
    public boolean onQueryTextSubmit(String query) {
        this.searchString(query);
        return true;
    }

    @Override
    public boolean onQueryTextChange(String newText) {
        this.searchString(newText);
        return true;
    }

    @Override
    public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
        if (this.isNoAbsenteeSelected) {
            ((BaseActivity) this.getActivity()).dismissDialog();
            this.isNoAbsenteeSelected = false;
            if (which == DialogAction.POSITIVE) {
                if (this.classSessionModel.isModifiable()) {
                    ((BaseActivity) this.getActivity()).showDialog(R.string.submit_attendance_confirm, R.string.yes, R.string.no, this);
                } else {
                    ((BaseActivity) this.getActivity()).showDialog(R.string.submit_attendance_confirm, R.string.submit_attendance_confirm_caution, R.string.yes, R.string.no, this);
                }
            } else if (which == DialogAction.NEGATIVE) {
                ((BaseActivity) this.getActivity()).dismissDialog();
            }
        }
        if (which == DialogAction.POSITIVE) {
            ((BaseActivity) this.getActivity()).dismissDialog();
            this.submitSessionModelList();
        } else if (which == DialogAction.NEGATIVE) {
            ((BaseActivity) this.getActivity()).dismissDialog();
        }
    }

    @Override
    public void onSelection(MaterialDialog dialog, View itemView, int position, CharSequence text) {
        ArrayList<String> sessionNumbers = MarkAttendanceDataManager.getInstance().getListOfSessionNumbers(classSessionModel);
        int sessionNumber = Integer.valueOf(sessionNumbers.get(sessionNumbers.indexOf(text)));
        this.requestSessionModelList(sessionNumber, true);
    }

    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        if (buttonView.getId() == R.id.session_student_list_mark_absentee_switch) {
            this.mStudentListAdapter.setMarkAbsenteeMode(!isChecked);
            for (Student student : mStudentListAdapter.getStudentList()) {
                student.setAbsent(!student.isAbsent());
            }
            changeCountInTitle();
        }
    }

    public void changeCountInTitle() {
        int countAbsent = 0;
        int countPresent = 0;
        for (Student student : mStudentListAdapter.getStudentList()) {
            if (student.isAbsent()) {
                countAbsent++;
            } else {
                countPresent++;
            }
        }
        this.mStudentListCardTitleTextView.setText(R.string.list_of_students);
        this.mStudentListCardTitleTextView.setText(this.mStudentListCardTitleTextView.getText().toString() + "  A: " + countAbsent + " P: " + countPresent);
        List<Student> studentList = mStudentListAdapter.getStudentList();
        Collections.sort(studentList, new StudentComparotar(!mStudentListMarkSwitch.isChecked()));
        mStudentListAdapter.setStudentList(studentList);
        notifyDataChanged();
    }

    public void shareOnSupportedApps(String text) {
        PackageManager pm = DataManager.getInstance().getApplication().getCurrentActivity().getPackageManager();

        ArrayList<Intent> targets = new ArrayList<>();
        Intent testIntent = new Intent(Intent.ACTION_SEND);
        testIntent.setType("text/plain");
        String subject = getString(R.string.subject_share, classSessionModel.getSubject().getName(), classSessionModel.getSessionNumber());

        List<ResolveInfo> resolvedIntents = pm.queryIntentActivities(testIntent, 0);
        for (ResolveInfo info : resolvedIntents) {
            String packageName = info.activityInfo.packageName;
            if (packageName.equals(Constants.packageWhatsApp) ||
                    packageName.equals(Constants.packageOutlook) ||
                    packageName.equals(Constants.packageTeams)) {

                Intent intent = new Intent(Intent.ACTION_SEND);
                intent.setType("text/plain");
                intent.putExtra(Intent.EXTRA_SUBJECT, subject);
                intent.putExtra(Intent.EXTRA_TEXT, text);
                intent.setPackage(info.activityInfo.packageName);
                intent.setClassName(info.activityInfo.packageName, info.activityInfo.name);
                targets.add(intent);
            }
        }
        if (targets.isEmpty()) {
            Banner.showBanner(getString(R.string.apps_not_installed));
            return;
        }
        Intent chooserIntent = Intent.createChooser(targets.remove(0), getString(R.string.title_share_dialog));
        chooserIntent.putExtra(Intent.EXTRA_INITIAL_INTENTS, targets.toArray(new Parcelable[]{}));
        startActivity(chooserIntent);
    }

    String replaceSpecialCh(String string) {
        return string.replaceAll("[;\\/:*?\"<>|&']", "_");
    }
}


