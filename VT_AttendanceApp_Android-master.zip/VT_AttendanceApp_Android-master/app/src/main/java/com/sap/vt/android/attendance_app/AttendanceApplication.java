package com.sap.vt.android.attendance_app;

import android.app.Activity;
import android.app.Application;
import android.content.Intent;

import com.sap.vt.android.attendance_app.manager.DataManager;
import com.sap.vt.android.attendance_app.manager.MarkAttendanceDataManager;
import com.sap.vt.android.attendance_app.ui.activity.LoginActivity;

/**
 * Created by I322051 on 3/30/2017.
 */

public class AttendanceApplication extends Application {

    private Activity mCurrentActivity = null;

    @Override
    public void onCreate() {
        super.onCreate();

        DataManager.getInstance().setApplication(this);
        MarkAttendanceDataManager.getInstance().setApplication(this);
    }

    private void showLoginActivity() {
        Intent loginIntent = new Intent(this, LoginActivity.class);
        loginIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        loginIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
        this.startActivity(loginIntent);
    }

    @Override
    public void onTerminate() {
        super.onTerminate();
    }

    public void resetData() {
        DataManager.getInstance().resetData();
        MarkAttendanceDataManager.getInstance().resetData();
        this.showLoginActivity();
    }

    public Activity getCurrentActivity(){
        return mCurrentActivity;
    }
    public void setCurrentActivity(Activity mCurrentActivity){
        this.mCurrentActivity = mCurrentActivity;
    }

}
