package com.sap.vt.android.attendance_app.ui.fragment;

import android.app.Activity;
import android.app.Fragment;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.sap.vt.R;
import com.sap.vt.android.attendance_app.manager.MarkAttendanceDataManager;
import com.sap.vt.android.attendance_app.model.Faculty;
import com.sap.vt.android.attendance_app.ui.activity.BaseActivity;
import com.sap.vt.android.attendance_app.ui.activity.MainActivity;

import de.hdodenhof.circleimageview.CircleImageView;

/**
 * Created by I327891 on 13-Jul-17.
 */

public class ProfileFragment extends Fragment implements MarkAttendanceDataManager.OnFacultyDataListener {

    public static final String TAG = "Fragment.Profile";

    FragmentListener mListener;
    CircleImageView profilePicImgView;
    TextView nameTextView, emailTextView, phoneTextView;

    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_profile, container, false);
        profilePicImgView = (CircleImageView) view.findViewById(R.id.profile_pic);
        nameTextView = (TextView) view.findViewById(R.id.profile_name);
        emailTextView = (TextView) view.findViewById(R.id.profile_email);
        phoneTextView = (TextView) view.findViewById(R.id.profile_phone);
        MarkAttendanceDataManager.getInstance().addFacultyModelListener(this);

        return view;
    }

    @Override
    public void onStart() {
        super.onStart();
        ((BaseActivity) getActivity()).showProgressDialog(R.string.loading_data);
        MarkAttendanceDataManager.getInstance().requestFacultyModelList(false);
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof MainActivity) {
            this.mListener = (FragmentListener) getActivity();
        }
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        if (activity instanceof MainActivity) {
            this.mListener = (FragmentListener) getActivity();
        }
    }

    @Override
    public void onDestroyView() {
        MarkAttendanceDataManager.getInstance().removeFacultyModelListener(this);
        ((BaseActivity) getActivity()).dismissDialog();
        super.onDestroyView();
    }

    @Override
    public void onFacultyDataAvailable(Faculty faculty) {
        if (faculty.getProfilePic() == null) {
            this.profilePicImgView.setImageResource(R.drawable.ic_person_grey_600_48dp);
            this.profilePicImgView.setBorderColor(getResources().getColor(R.color.colorGrey700));
            this.profilePicImgView.setBorderWidth((int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 5, getResources().getDisplayMetrics()));
        } else {
            this.profilePicImgView.setImageDrawable(faculty.getProfilePic());
        }
        this.nameTextView.setText(faculty.getName());
        this.emailTextView.setText(faculty.getEmail());
        this.phoneTextView.setText(faculty.getPhoneNumber());
        ((BaseActivity) getActivity()).dismissDialog();
    }
}
